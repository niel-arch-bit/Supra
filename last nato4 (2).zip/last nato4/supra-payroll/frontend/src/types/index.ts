export type User = {
  id: number;
  username: string;
  email: string;
  full_name: string;
  role: 'administrator' | 'hr_payroll_staff';
  is_active: boolean;
  must_change_password: boolean;
  created_at?: string;
};

export type Employee = {
  id: number;
  employee_id: string;
  first_name: string;
  middle_name: string | null;
  last_name: string;
  gender: string | null;
  date_of_birth: string | null;
  contact_number: string | null;
  email: string | null;
  home_address: string | null;
  department_id: number | null;
  job_position: string | null;
  employment_status: string;
  date_hired: string;
  basic_monthly_salary: number;
  is_archived: number;
  created_at: string;
  updated_at: string;
  department_name?: string;
  full_name?: string;
};

export type Attendance = {
  id: number;
  employee_id: number;
  attendance_date: string;
  time_in: string | null;
  time_out: string | null;
  total_hours: number;
  status: string;
  notes: string | null;
  created_by: number | null;
  created_at: string;
  updated_at: string;
  employee_id_str?: string;
  first_name?: string;
  last_name?: string;
  department_name?: string;
};

export type Payroll = {
  id: number;
  employee_id: number;
  period_start: string;
  period_end: string;
  basic_pay: number;
  overtime_pay: number;
  allowances: number;
  bonuses: number;
  other_earnings: number;
  total_earnings: number;
  absence_deduction: number;
  government_contributions: number;
  tax_withholding: number;
  other_deductions: number;
  total_deductions: number;
  net_pay: number;
  status: string;
  processed_by: number | null;
  approved_by: number | null;
  processed_at: string | null;
  approved_at: string | null;
  created_at: string;
  updated_at: string;
  employee_id_str?: string;
  first_name?: string;
  last_name?: string;
  job_position?: string;
  department_name?: string;
  processed_by_name?: string;
  approved_by_name?: string;
};

export type Department = {
  id: number;
  name: string;
  description: string | null;
  created_at: string;
  updated_at: string;
};

export type ActivityLog = {
  id: number;
  user_id: number | null;
  username: string | null;
  action: string;
  entity_type: string | null;
  entity_id: number | null;
  description: string | null;
  ip_address: string | null;
  user_agent: string | null;
  created_at: string;
  user_full_name?: string;
};

export type EmployeeFile = {
  id: number;
  employee_id: number;
  document_name: string;
  document_category: string;
  file_name: string;
  file_path: string;
  file_type: string;
  file_size: number;
  uploaded_by: number;
  upload_date: string;
  employee_id_str?: string;
  first_name?: string;
  last_name?: string;
  uploaded_by_name?: string;
};

export type DashboardStats = {
  total_employees: number;
  present_today: number;
  absent_today: number;
  pending_payroll: number;
  total_payroll_current_period: number;
};
