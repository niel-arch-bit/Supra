const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '../../.env') });

const { initDb } = require('./db');

async function seed() {
  await initDb();
  console.log('🌱 Database seeded.');
}

seed().catch(err => {
  console.error('❌ Seed error:', err);
  process.exit(1);
});