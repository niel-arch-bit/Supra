import axios, { AxiosError, InternalAxiosRequestConfig } from 'axios';

const api = axios.create({
  // Vite proxies this locally; Netlify proxies the same path to the hosted API.
  baseURL: '/api',
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor - add auth token
api.interceptors.request.use(
  (config: InternalAxiosRequestConfig) => {
    const token = localStorage.getItem('supra_token');
    if (token && config.headers) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor - handle 401
api.interceptors.response.use(
  (response) => response,
  (error: AxiosError) => {
    const requestUrl = error.config?.url || '';
    const isCredentialForm = requestUrl.endsWith('/auth/login') || requestUrl.endsWith('/auth/change-password');
    if (error.response?.status === 401 && !isCredentialForm && localStorage.getItem('supra_token')) {
      localStorage.removeItem('supra_token');
      localStorage.removeItem('supra_user');
      if (window.location.pathname !== '/login') window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export default api;

export type { AxiosError };
