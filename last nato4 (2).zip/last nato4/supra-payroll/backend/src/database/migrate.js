const path = require('path');
const fs = require('fs');
const { initDb } = require('./db');
const { DB_PATH } = require('../config/storage');
const SCHEMA_PATH = path.join(__dirname, 'schema.sql');

const dbDir = path.dirname(DB_PATH);
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true });
}

async function migrate() {
  const db = await initDb();

  console.log('🔄 Running migrations...');

  const schema = fs.readFileSync(SCHEMA_PATH, 'utf8');
  db.exec(schema);
  console.log('✓ Migration completed successfully');

  fs.writeFileSync(DB_PATH, Buffer.from(db.export()));
  process.exit(0);
}

migrate().catch(err => {
  console.error('❌ Migration error:', err);
  process.exit(1);
});
