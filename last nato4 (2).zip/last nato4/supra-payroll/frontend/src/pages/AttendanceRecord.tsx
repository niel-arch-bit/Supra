import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-hot-toast';
import api from '../services/api';
import { ArrowLeft, Clock, Loader2, CheckCircle2 } from 'lucide-react';

export default function AttendanceRecord() {
  const navigate = useNavigate();
  const [employees, setEmployees] = useState<any[]>([]);
  [useState(''), useState('')];
  const [selectedEmployee, setSelectedEmployee] = useState<number | null>(null);
  const [action, setAction] = useState<'time_in' | 'time_out'>('time_in');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    api.get('/employees/', { params: { archived: 'false', limit: 100 } })
      .then((res) => setEmployees(res.data.employees))
      .catch(() => toast.error('Failed to load employees'));
  }, []);

  const recordAttendance = async () => {
    if (!selectedEmployee) {
      toast.error('Please select an employee');
      return;
    }
    setSaving(true);
    try {
      await api.post('/attendance/record', { employee_id: selectedEmployee, action });
      toast.success(`${action.replace('_', ' ')} recorded successfully!`);
      setSelectedEmployee(null);
    } catch (err: any) {
      toast.error(err.response?.data?.error || 'Failed to record attendance.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <button onClick={() => navigate('/dashboard')} className="flex items-center gap-2 text-gray-600 hover:text-supra-red-600 mb-4">
            <ArrowLeft className="w-4 h-4" />
            Back to Dashboard
          </button>
          <h1 className="text-2xl font-bold text-gray-900">Record Attendance</h1>
          <p className="text-gray-500">Time-in and time-out tracking</p>
        </div>
      </div>

      <div className="supra-card p-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Select Employee</label>
            <select
              value={selectedEmployee || ''}
              onChange={(e) => setSelectedEmployee(e.target.value ? parseInt(e.target.value) : null)}
              className="supra-input"
            >
              <option value="">-- Select Employee --</option>
              {employees.map((e) => (
                <option key={e.id} value={e.id}>{e.employee_id} - {e.first_name} {e.last_name}</option>
              ))}
            </select>
          </div>
          <div className="flex items-end">
            <div className="flex gap-2">
              <button
                onClick={() => setAction('time_in')}
                className={`px-6 py-3 rounded-xl font-semibold transition-all ${action === 'time_in' ? 'bg-supra-red-600 text-white' : 'bg-white border border-gray-200 text-gray-700 hover:bg-gray-50'}`}
              >
                <Clock className="w-4 h-4 mr-2" />
                Time In
              </button>
              <button
                onClick={() => setAction('time_out')}
                className={`px-6 py-3 rounded-xl font-semibold transition-all ${action === 'time_out' ? 'bg-supra-red-600 text-white' : 'bg-white border border-gray-200 text-gray-700 hover:bg-gray-50'}`}
              >
                <Clock className="w-4 h-4 mr-2" />
                Time Out
              </button>
            </div>
          </div>
        </div>

        <div className="mt-8 flex items-center justify-center">
          <button
            onClick={recordAttendance}
            disabled={!selectedEmployee || saving}
            className="supra-btn-primary px-12 py-4 disabled:opacity-60 disabled:cursor-not-allowed flex items-center gap-2"
          >
            {saving ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <>
                <CheckCircle2 className="w-5 h-5" />
                Record {action.replace('_', ' ')}
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
