const express = require('express');
const router = express.Router();
const employee201Controller = require('../controllers/employee201Controller');
const { authenticateToken, requireActiveUser, authorizeRoles } = require('../middleware/auth');
const { upload } = require('../middleware/upload');

router.get('/', authenticateToken, requireActiveUser, employee201Controller.getAll);
router.post('/upload', authenticateToken, requireActiveUser, authorizeRoles('administrator', 'hr_payroll_staff'), upload.single('document'), employee201Controller.uploadDocument);
router.get('/download/:id', authenticateToken, requireActiveUser, employee201Controller.downloadDocument);
router.delete('/:id', authenticateToken, requireActiveUser, authorizeRoles('administrator'), employee201Controller.deleteDocument);

module.exports = router;