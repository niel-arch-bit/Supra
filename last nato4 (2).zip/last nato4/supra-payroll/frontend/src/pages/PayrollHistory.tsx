import { useState, useEffect } from 'react';
import { toast } from 'react-hot-toast';
import api from '../services/api';
import { CheckCircle2 } from 'lucide-react';

export default function PayrollHistory() {
  const [records, setRecords] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('');

  useEffect(() => {
    loadRecords();
  }, [statusFilter]);

  const loadRecords = async () => {
    setLoading(true);
    try {
      const res = await api.get('/payroll/', { params: { status: statusFilter || undefined } });
      setRecords(res.data.records);
    } catch (err) {
      toast.error('Failed to load payroll records');
    } finally {
      setLoading(false);
    }
  };

  const markPaid = async (id: number) => {
    try {
      await api.patch(`/payroll/${id}/pay`);
      toast.success('Payroll marked as paid');
      loadRecords();
    } catch (err: any) {
      toast.error(err.response?.data?.error || 'Failed to mark as paid');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Payroll History</h1>
          <p className="text-gray-500">View and manage payroll records</p>
        </div>
      </div>

      <div className="supra-card p-6">
        <div className="flex items-center gap-4 mb-6">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="supra-input"
          >
            <option value="">All Status</option>
            <option value="Draft">Draft</option>
            <option value="Confirmed">Confirmed</option>
            <option value="Paid">Paid</option>
            <option value="Cancelled">Cancelled</option>
          </select>
        </div>

        <div className="overflow-x-auto">
          <table className="supra-table">
            <thead>
              <tr>
                <th>Employee ID</th>
                <th>Employee Name</th>
                <th>Period</th>
                <th>Basic Pay</th>
                <th>Net Pay</th>
                <th>Status</th>
                <th className="text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={7} className="text-center py-8 text-gray-500">Loading...</td></tr>
              ) : records.length === 0 ? (
                <tr><td colSpan={7} className="text-center py-8 text-gray-500">No payroll records found.</td></tr>
              ) : (
                records.map((r) => (
                  <tr key={r.id} className="hover:bg-gray-50/50 transition-colors">
                    <td className="font-medium text-gray-900">{r.employee_id_str}</td>
                    <td className="text-gray-700">{r.first_name} {r.last_name}</td>
                    <td className="text-gray-700 text-sm">{r.period_start} to {r.period_end}</td>
                    <td className="text-gray-700 text-sm">₱{r.basic_pay}</td>
                    <td className="text-gray-700 text-sm font-medium">₱{r.net_pay}</td>
                    <td>
                      <span className={`supra-badge ${r.status === 'Paid' ? 'badge-paid' : r.status === 'Confirmed' ? 'badge-confirmed' : r.status === 'Draft' ? 'badge-draft' : 'badge-pending'}`}>
                        {r.status}
                      </span>
                    </td>
                    <td className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button onClick={() => markPaid(r.id)} disabled={r.status !== 'Confirmed'} className="text-green-600 hover:text-green-800 disabled:opacity-50" title="Mark as Paid">
                          <CheckCircle2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
