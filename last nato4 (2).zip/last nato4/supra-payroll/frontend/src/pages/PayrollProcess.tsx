import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-hot-toast';
import api from '../services/api';
import { ArrowLeft, Calculator, Loader2 } from 'lucide-react';

export default function PayrollProcess() {
  const navigate = useNavigate();
  const [employees, setEmployees] = useState<any[]>([]);
  const [formData, setFormData] = useState({ employee_id: '', period_start: '', period_end: '' });
  const [calculation, setCalculation] = useState<any>(null);
  const [processing, setProcessing] = useState(false);

  useEffect(() => {
    api.get('/employees/', { params: { archived: 'false', limit: 100 } })
      .then((res) => setEmployees(res.data.employees))
      .catch(() => toast.error('Failed to load employees'));
  }, []);

  const processPayroll = async () => {
    setProcessing(true);
    try {
      const res = await api.post('/payroll/process', formData);
      setCalculation(res.data.calculation);
      toast.success('Payroll processed successfully!');
    } catch (err: any) {
      toast.error(err.response?.data?.error || 'Failed to process payroll.');
    } finally {
      setProcessing(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <button onClick={() => navigate('/dashboard')} className="flex items-center gap-2 text-gray-600 hover:text-supra-red-600 mb-4">
            <ArrowLeft className="w-4 h-4" />
            Back to Dashboard
          </button>
          <h1 className="text-2xl font-bold text-gray-900">Process Payroll</h1>
          <p className="text-gray-500">Calculate and confirm employee payroll</p>
        </div>
      </div>

      <div className="supra-card p-6">
        <form onSubmit={(e) => { e.preventDefault(); processPayroll(); }} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Select Employee</label>
              <select
                value={formData.employee_id}
                onChange={(e) => setFormData({ ...formData, employee_id: e.target.value })}
                className="supra-input"
                required
              >
                <option value="">-- Select Employee --</option>
                {employees.map((e) => (
                  <option key={e.id} value={e.id}>{e.employee_id} - {e.first_name} {e.last_name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Period Start</label>
              <input
                type="date"
                value={formData.period_start}
                onChange={(e) => setFormData({ ...formData, period_start: e.target.value })}
                className="supra-input"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Period End</label>
              <input
                type="date"
                value={formData.period_end}
                onChange={(e) => setFormData({ ...formData, period_end: e.target.value })}
                className="supra-input"
                required
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={processing}
            className="supra-btn-primary w-full py-4 disabled:opacity-60 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {processing ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <>
                <Calculator className="w-5 h-5" />
                Calculate Payroll
              </>
            )}
          </button>
        </form>
      </div>

      {calculation && (
        <div className="supra-card p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold text-gray-900">Payroll Calculation Summary</h2>
            <button onClick={() => {}} className="supra-btn-secondary px-6 py-2">
              Confirm Payroll
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3 className="font-semibold text-gray-900 text-sm uppercase tracking-wider">Earnings</h3>
              <div className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Basic Pay</span>
                  <span className="font-medium text-gray-900">₱{calculation.basic_pay.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Overtime Pay</span>
                  <span className="font-medium text-gray-900">₱{calculation.overtime_pay.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Allowances</span>
                  <span className="font-medium text-gray-900">₱{calculation.allowances.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Bonuses</span>
                  <span className="font-medium text-gray-900">₱{calculation.bonuses.toLocaleString()}</span>
                </div>
                <div className="h-px bg-gray-100" />
                <div className="flex justify-between text-sm font-bold text-gray-900">
                  <span>Total Earnings</span>
                  <span>₱{calculation.total_earnings.toLocaleString()}</span>
                </div>
              </div>
            </div>
            <div className="space-y-4">
              <h3 className="font-semibold text-gray-900 text-sm uppercase tracking-wider">Deductions</h3>
              <div className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Absence Deduction</span>
                  <span className="font-medium text-gray-900">₱{calculation.absence_deduction.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Government Contributions</span>
                  <span className="font-medium text-gray-900">₱{calculation.government_contributions.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Tax Withholding</span>
                  <span className="font-medium text-gray-900">₱{calculation.tax_withholding.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Other Deductions</span>
                  <span className="font-medium text-gray-900">₱{calculation.other_deductions.toLocaleString()}</span>
                </div>
                <div className="h-px bg-gray-100" />
                <div className="flex justify-between text-sm font-bold text-gray-900">
                  <span>Total Deductions</span>
                  <span>₱{calculation.total_deductions.toLocaleString()}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 p-6 bg-supra-black rounded-xl text-white">
            <div className="flex justify-between text-2xl font-bold">
              <span>Net Pay</span>
              <span>₱{calculation.net_pay.toLocaleString()}</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
