import { useState, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { toast } from 'react-hot-toast';
import { ArrowLeft, LockKeyhole, ShieldCheck, UserRound } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

export default function Profile() {
  const { user, changePassword } = useAuth();
  const [form, setForm] = useState({ current_password: '', new_password: '', confirm_password: '' });
  const [saving, setSaving] = useState(false);

  const submitPassword = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (form.new_password !== form.confirm_password) {
      toast.error('New passwords do not match.');
      return;
    }

    setSaving(true);
    try {
      await changePassword(form.current_password, form.new_password);
      setForm({ current_password: '', new_password: '', confirm_password: '' });
      toast.success('Password updated.');
    } catch (error: any) {
      toast.error(error.response?.data?.error || 'Could not update password.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="mx-auto max-w-4xl space-y-6">
      <header>
        <Link to="/dashboard" className="mb-4 inline-flex items-center gap-2 text-sm text-gray-500 hover:text-supra-red-600">
          <ArrowLeft className="h-4 w-4" /> Back to dashboard
        </Link>
        <h1 className="text-2xl font-bold tracking-tight text-gray-900">My profile</h1>
        <p className="mt-1 text-sm text-gray-500">Account details and password settings.</p>
      </header>

      <section className="grid gap-5 md:grid-cols-2">
        <article className="rounded-2xl border border-gray-200 bg-white p-6 shadow-sm">
          <div className="flex items-center gap-3">
            <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-red-50 text-supra-red-600">
              <UserRound className="h-5 w-5" />
            </span>
            <div>
              <h2 className="font-semibold text-gray-900">Account information</h2>
              <p className="text-xs text-gray-500">Your SUPRA login profile</p>
            </div>
          </div>
          <dl className="mt-6 space-y-4">
            <div>
              <dt className="text-xs font-medium uppercase tracking-wide text-gray-400">Full name</dt>
              <dd className="mt-1 text-sm font-medium text-gray-900">{user?.full_name}</dd>
            </div>
            <div>
              <dt className="text-xs font-medium uppercase tracking-wide text-gray-400">Username</dt>
              <dd className="mt-1 text-sm text-gray-700">{user?.username}</dd>
            </div>
            <div>
              <dt className="text-xs font-medium uppercase tracking-wide text-gray-400">Email</dt>
              <dd className="mt-1 text-sm text-gray-700">{user?.email}</dd>
            </div>
            <div>
              <dt className="text-xs font-medium uppercase tracking-wide text-gray-400">Role</dt>
              <dd className="mt-1 inline-flex items-center gap-1.5 text-sm capitalize text-gray-700">
                <ShieldCheck className="h-4 w-4 text-gray-400" /> {user?.role.replace(/_/g, ' ')}
              </dd>
            </div>
          </dl>
        </article>

        <article className="rounded-2xl border border-gray-200 bg-white p-6 shadow-sm">
          <div className="flex items-center gap-3">
            <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-gray-100 text-gray-700">
              <LockKeyhole className="h-5 w-5" />
            </span>
            <div>
              <h2 className="font-semibold text-gray-900">Change password</h2>
              <p className="text-xs text-gray-500">Update your account password anytime.</p>
            </div>
          </div>

          <form onSubmit={submitPassword} className="mt-6 space-y-4">
            <label className="block text-sm font-medium text-gray-700">
              Current password
              <input
                type="password"
                autoComplete="current-password"
                value={form.current_password}
                onChange={(event) => setForm({ ...form, current_password: event.target.value })}
                className="supra-input mt-1.5"
                required
              />
            </label>
            <label className="block text-sm font-medium text-gray-700">
              New password
              <input
                type="password"
                autoComplete="new-password"
                minLength={6}
                value={form.new_password}
                onChange={(event) => setForm({ ...form, new_password: event.target.value })}
                className="supra-input mt-1.5"
                required
              />
            </label>
            <label className="block text-sm font-medium text-gray-700">
              Confirm new password
              <input
                type="password"
                autoComplete="new-password"
                minLength={6}
                value={form.confirm_password}
                onChange={(event) => setForm({ ...form, confirm_password: event.target.value })}
                className="supra-input mt-1.5"
                required
              />
            </label>
            <button type="submit" disabled={saving} className="supra-btn-primary w-full disabled:cursor-not-allowed disabled:opacity-60">
              {saving ? 'Saving…' : 'Save new password'}
            </button>
          </form>
        </article>
      </section>
    </div>
  );
}
