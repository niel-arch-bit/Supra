import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-hot-toast';
import api from '../services/api';
import { ArrowLeft, Search, Filter } from 'lucide-react';

export default function AttendanceRecords() {
  const navigate = useNavigate();
  const [records, setRecords] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({ employee_id: '', start_date: '', end_date: '' });

  useEffect(() => {
    loadRecords();
  }, [filters]);

  const loadRecords = async () => {
    setLoading(true);
    try {
      const res = await api.get('/attendance/', { params: filters });
      setRecords(res.data.records);
    } catch (err) {
      toast.error('Failed to load attendance records');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <button onClick={() => navigate('/dashboard')} className="flex items-center gap-2 text-gray-600 hover:text-supra-red-600 mb-4">
            <ArrowLeft className="w-4 h-4" />
            Back to Dashboard
          </button>
          <h1 className="text-2xl font-bold text-gray-900">Attendance Records</h1>
          <p className="text-gray-500">View and manage attendance entries</p>
        </div>
      </div>

      <div className="supra-card p-6">
        <div className="flex flex-wrap items-center gap-4 mb-6">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search by employee name or ID"
              className="supra-input pl-10"
            />
          </div>
          <input
            type="date"
            value={filters.start_date}
            onChange={(e) => setFilters({ ...filters, start_date: e.target.value })}
            className="supra-input"
          />
          <input
            type="date"
            value={filters.end_date}
            onChange={(e) => setFilters({ ...filters, end_date: e.target.value })}
            className="supra-input"
          />
          <button onClick={loadRecords} className="supra-btn-secondary px-4">
            <Filter className="w-4 h-4 mr-2" />
            Filter
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="supra-table">
            <thead>
              <tr>
                <th>Employee ID</th>
                <th>Employee Name</th>
                <th>Date</th>
                <th>Time In</th>
                <th>Time Out</th>
                <th>Total Hours</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={7} className="text-center py-8 text-gray-500">Loading...</td></tr>
              ) : records.length === 0 ? (
                <tr><td colSpan={7} className="text-center py-8 text-gray-500">No attendance records found.</td></tr>
              ) : (
                records.map((r) => (
                  <tr key={r.id} className="hover:bg-gray-50/50 transition-colors">
                    <td className="font-medium text-gray-900">{r.employee_id}</td>
                    <td className="text-gray-700">{r.first_name} {r.last_name}</td>
                    <td className="text-gray-700 text-sm">{r.attendance_date}</td>
                    <td className="text-gray-700 text-sm">{r.time_in || '-'}</td>
                    <td className="text-gray-700 text-sm">{r.time_out || '-'}</td>
                    <td className="text-gray-700 text-sm">{r.total_hours || 0}</td>
                    <td>
                      <span className={`supra-badge ${r.status === 'Present' ? 'badge-present' : 'badge-absent'}`}>
                        {r.status}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
