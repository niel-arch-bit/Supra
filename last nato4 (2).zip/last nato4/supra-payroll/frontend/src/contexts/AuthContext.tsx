import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import api from '../services/api';

export type User = {
  id: number;
  username: string;
  email: string;
  full_name: string;
  role: 'administrator' | 'hr_payroll_staff';
  is_active?: boolean;
  must_change_password: boolean;
  created_at?: string;
};

type AuthContextType = {
  user: User | null;
  token: string | null;
  login: (username: string, password: string) => Promise<User>;
  register: (data: { full_name: string; username: string; email: string; password: string; confirm_password: string }) => Promise<void>;
  logout: () => void;
  changePassword: (current_password: string, new_password: string) => Promise<void>;
  isLoading: boolean;
  isAuthenticated: boolean;
  hasRole: (role: string) => boolean;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    let isMounted = true;
    const storedToken = localStorage.getItem('supra_token');
    const storedUser = localStorage.getItem('supra_user');

    const restoreSession = async () => {
      if (!storedToken) {
        if (isMounted) setIsLoading(false);
        return;
      }

      let cachedUser: User | null = null;
      try {
        cachedUser = storedUser ? JSON.parse(storedUser) as User : null;
      } catch {
        localStorage.removeItem('supra_user');
      }

      if (isMounted) {
        setToken(storedToken);
        if (cachedUser) setUser(cachedUser);
      }

      try {
        const response = await api.get('/auth/me');
        if (isMounted) {
          setUser(response.data.user);
          localStorage.setItem('supra_user', JSON.stringify(response.data.user));
        }
      } catch (error) {
        const status = (error as { response?: { status?: number } }).response?.status;
        if (status === 401 || !cachedUser) {
          localStorage.removeItem('supra_token');
          localStorage.removeItem('supra_user');
          if (isMounted) {
            setToken(null);
            setUser(null);
          }
        }
      } finally {
        if (isMounted) setIsLoading(false);
      }
    };

    void restoreSession();
    return () => { isMounted = false; };
  }, []);

  const login = async (username: string, password: string) => {
    const response = await api.post('/auth/login', { username, password });
    const { token: newToken, user: userData } = response.data as { token: string; user: User };
    setToken(newToken);
    setUser(userData);
    localStorage.setItem('supra_token', newToken);
    localStorage.setItem('supra_user', JSON.stringify(userData));
    return userData;
  };

  const register = async (data: { full_name: string; username: string; email: string; password: string; confirm_password: string }) => {
    await api.post('/auth/register', data);
  };

  const logout = () => {
    setUser(null);
    setToken(null);
    localStorage.removeItem('supra_token');
    localStorage.removeItem('supra_user');
  };

  const changePassword = async (current_password: string, new_password: string) => {
    await api.post('/auth/change-password', { current_password, new_password });
    setUser(prev => prev ? { ...prev, must_change_password: false } : null);
    const stored = localStorage.getItem('supra_user');
    if (stored) {
      const u = JSON.parse(stored);
      u.must_change_password = false;
      localStorage.setItem('supra_user', JSON.stringify(u));
    }
  };

  const isAuthenticated = !!token && !!user;
  const hasRole = (role: string) => user?.role === role;

  return (
    <AuthContext.Provider value={{ user, token, login, register, logout, changePassword, isLoading, isAuthenticated, hasRole }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
};
