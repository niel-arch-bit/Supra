const Database = require('better-sqlite3');
const { logActivity } = require('../middleware/activityLogger');

const { DB_PATH } = require('../config/storage');
const db = new Database(DB_PATH);
db.pragma('foreign_keys = ON');

exports.getAll = (req, res) => {
  try {
    const { employee_id, page = 1, limit = 50 } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);

    let query = `
      SELECT p.*, e.employee_id as employee_id_str, e.first_name, e.last_name, e.job_position,
        d.name as department_name,
        u_processed.full_name as processed_by_name
      FROM payroll p
      JOIN employees e ON p.employee_id = e.id
      LEFT JOIN departments d ON e.department_id = d.id
      LEFT JOIN users u_processed ON p.processed_by = u_processed.id
      WHERE p.status IN ('Confirmed', 'Paid')
    `;
    const params = [];

    if (employee_id) {
      query += ` AND e.id = ?`;
      params.push(employee_id);
    }

    query += ` ORDER BY p.created_at DESC LIMIT ? OFFSET ?`;
    params.push(parseInt(limit), offset);

    const records = db.prepare(query).all(params);
    res.json({ records });
  } catch (err) {
    console.error('Get payslips error:', err);
    res.status(500).json({ error: 'Internal server error.' });
  }
};

exports.getById = (req, res) => {
  try {
    const payroll = db.prepare(`
      SELECT p.*, e.employee_id as employee_id_str, e.first_name, e.last_name, e.job_position,
        d.name as department_name,
        u_processed.full_name as processed_by_name,
        u_approved.full_name as approved_by_name
      FROM payroll p
      JOIN employees e ON p.employee_id = e.id
      LEFT JOIN departments d ON e.department_id = d.id
      LEFT JOIN users u_processed ON p.processed_by = u_processed.id
      LEFT JOIN users u_approved ON p.approved_by = u_approved.id
      WHERE p.id = ?
    `).get(req.params.id);

    if (!payroll) {
      return res.status(404).json({ error: 'Payroll record not found.' });
    }

    logActivity(req.user.id, req.user.username, 'PAYSLIP_VIEWED', 'payroll', req.params.id,
      `Viewed payslip for payroll ID ${req.params.id}`, req);

    res.json({ payslip: payroll });
  } catch (err) {
    console.error('Get payslip error:', err);
    res.status(500).json({ error: 'Internal server error.' });
  }
};

exports.generate = (req, res) => {
  try {
    const { payroll_id } = req.body;

    const payroll = db.prepare('SELECT * FROM payroll WHERE id = ?').get(payroll_id);
    if (!payroll) {
      return res.status(404).json({ error: 'Payroll record not found.' });
    }

    if (payroll.status !== 'Confirmed' && payroll.status !== 'Paid') {
      return res.status(400).json({ error: 'Payslip can only be generated from confirmed payroll.' });
    }

    const existing = db.prepare('SELECT * FROM payslips WHERE payroll_id = ?').get(payroll_id);
    if (existing) {
      return res.status(409).json({ error: 'Payslip already exists for this payroll.' });
    }

    const stmt = db.prepare(`
      INSERT INTO payslips (payroll_id, employee_id, period_start, period_end, net_pay, generated_by)
      VALUES (?, ?, ?, ?, ?, ?)
    `);
    const result = stmt.run(payroll_id, payroll.employee_id, payroll.period_start, payroll.period_end, payroll.net_pay, req.user.id);

    logActivity(req.user.id, req.user.username, 'PAYSLIP_GENERATED', 'payslip', result.lastInsertRowid,
      `Generated payslip for payroll ID ${payroll_id}`, req);

    res.status(201).json({ message: 'Payslip generated successfully.', id: result.lastInsertRowid });
  } catch (err) {
    console.error('Generate payslip error:', err);
    res.status(500).json({ error: 'Internal server error.' });
  }
};
