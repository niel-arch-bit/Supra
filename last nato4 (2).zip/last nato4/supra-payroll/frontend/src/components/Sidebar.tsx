import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { LayoutDashboard, Users, Clock, CreditCard, FileText, Folder, Shield, LogOut, Settings, Activity, Briefcase, ChevronDown, X } from 'lucide-react';
import { SupraLogo } from './SupraLogo';

const navItems = [
  { name: 'Dashboard', path: '/dashboard', icon: LayoutDashboard, roles: ['administrator', 'hr_payroll_staff'] },
  { name: 'Manage Employees', path: '/employees', icon: Briefcase, roles: ['administrator', 'hr_payroll_staff'], children: [
    { name: 'Employee List', path: '/employees', icon: Users },
    { name: 'Add Employee', path: '/employees/add', icon: Users },
  ]},
  { name: 'Record Attendance', path: '/attendance', icon: Clock, roles: ['administrator', 'hr_payroll_staff'], children: [
    { name: 'Time In / Time Out', path: '/attendance/record', icon: Clock },
    { name: 'Attendance Records', path: '/attendance/records', icon: Activity },
    { name: 'Attendance Reports', path: '/attendance/reports', icon: FileText },
  ]},
  { name: 'Process Payroll', path: '/payroll', icon: CreditCard, roles: ['administrator', 'hr_payroll_staff'], children: [
    { name: 'Process Payroll', path: '/payroll/process', icon: CreditCard },
    { name: 'Payroll History', path: '/payroll/history', icon: FileText },
    { name: 'Print Payroll Report', path: '/payroll/report', icon: FileText },
  ]},
  { name: 'Generate Payslip', path: '/payslip', icon: FileText, roles: ['administrator', 'hr_payroll_staff'], children: [
    { name: 'View Payslip', path: '/payslip/view', icon: FileText },
    { name: 'Print / Export PDF', path: '/payslip/print', icon: FileText },
  ]},
  { name: 'Employee 201 Files', path: '/employee201', icon: Folder, roles: ['administrator', 'hr_payroll_staff'], children: [
    { name: 'Employee Files', path: '/employee201', icon: Folder },
    { name: 'Upload Documents', path: '/employee201/upload', icon: FileText },
  ]},
  { name: 'User Management', path: '/users', icon: Shield, roles: ['administrator'] },
  { name: 'Activity Logs', path: '/activity-logs', icon: Activity, roles: ['administrator'] },
  { name: 'Settings', path: '/settings', icon: Settings, roles: ['administrator', 'hr_payroll_staff'] },
];

export function Sidebar({ mobileOpen, onNavigate }: { mobileOpen: boolean; onNavigate: () => void }) {
  const { logout, hasRole } = useAuth();
  const location = useLocation();
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});

  const isActive = (path: string) => location.pathname === path || location.pathname.startsWith(path + '/');

  const visibleItems = navItems.filter(item => item.roles.some(r => hasRole(r)));

  return (
    <aside className={`fixed inset-y-0 left-0 z-50 w-72 max-w-[85vw] transform border-r border-gray-800 bg-supra-black text-white shadow-2xl transition-transform duration-300 lg:w-64 lg:translate-x-0 ${mobileOpen ? 'translate-x-0' : '-translate-x-full'}`}>
      <div className="flex flex-col h-full">
        <div className="flex items-start justify-between border-b border-gray-800 p-6">
          <div>
            <SupraLogo size="lg" className="text-white" />
            <p className="mt-2 text-xs text-gray-400">Employee Management &amp; Payroll</p>
          </div>
          <button type="button" onClick={onNavigate} className="rounded-lg p-1 text-gray-400 hover:bg-gray-800 hover:text-white lg:hidden" aria-label="Close navigation menu">
            <X className="h-5 w-5" />
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto p-4 space-y-1">
          {visibleItems.map((item) => {
            if (item.children) {
              const hasActiveChild = item.children.some(child => isActive(child.path));
              const isExpanded = expanded[item.name] ?? hasActiveChild;
              return (
                <div key={item.name} className="overflow-hidden">
                  <button
                    type="button"
                    onClick={() => setExpanded(current => ({ ...current, [item.name]: !isExpanded }))}
                    aria-expanded={isExpanded}
                    className="group flex w-full items-center justify-between rounded-lg px-4 py-3 text-sm font-semibold text-gray-300 transition-colors hover:bg-gray-800 hover:text-white"
                  >
                    <span className="flex items-center gap-3">
                      <item.icon className="h-5 w-5" />
                      {item.name}
                    </span>
                    <ChevronDown className={`h-4 w-4 transition-transform ${isExpanded ? 'rotate-180' : ''}`} />
                  </button>
                  <div className={`ml-4 space-y-1 py-2 ${isExpanded ? 'block' : 'hidden'}`}>
                    {item.children.map((child) => (
                      <Link
                        key={child.name}
                        to={child.path}
                        onClick={onNavigate}
                        className={`flex items-center gap-3 px-4 py-2 text-sm rounded-lg transition-colors ${
                          isActive(child.path)
                            ? 'bg-supra-red-600 text-white'
                            : 'text-gray-400 hover:text-white hover:bg-gray-800'
                        }`}
                      >
                        <child.icon className="w-4 h-4" />
                        <span>{child.name}</span>
                      </Link>
                    ))}
                  </div>
                </div>
              );
            }
            return (
              <Link
                key={item.name}
                to={item.path}
                onClick={onNavigate}
                className={`flex items-center gap-3 px-4 py-3 text-sm font-medium rounded-lg transition-colors ${
                  isActive(item.path)
                    ? 'bg-supra-red-600 text-white'
                    : 'text-gray-400 hover:text-white hover:bg-gray-800'
                }`}
              >
                <item.icon className="w-5 h-5" />
                <span>{item.name}</span>
              </Link>
            );
          })}
        </nav>

        <div className="p-4 border-t border-gray-800">
          <button
            onClick={logout}
            className="w-full flex items-center gap-3 px-4 py-3 text-sm font-medium text-red-400 hover:bg-red-500/10 hover:text-red-300 rounded-lg transition-colors"
          >
            <LogOut className="w-5 h-5" />
            <span>Logout</span>
          </button>
        </div>
      </div>
    </aside>
  );
}
