const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const Database = require('better-sqlite3');
const { logActivity } = require('../middleware/activityLogger');

const { DB_PATH } = require('../config/storage');
const db = new Database(DB_PATH);
db.pragma('foreign_keys = ON');

const JWT_SECRET = process.env.JWT_SECRET || 'your_supra_jwt_secret_change_in_production';
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '24h';

function generateToken(user) {
  return jwt.sign(
    { id: user.id, username: user.username, email: user.email, role: user.role, full_name: user.full_name },
    JWT_SECRET,
    { expiresIn: JWT_EXPIRES_IN }
  );
}

exports.login = (req, res) => {
  try {
    const { username, password } = req.body;

    if (!username || !password) {
      return res.status(400).json({ error: 'Username/email and password are required.' });
    }

    const user = db.prepare(
      'SELECT id, username, email, full_name, password_hash, role, is_active, must_change_password FROM users WHERE (username = ? OR email = ?) AND is_active = 1'
    ).get(username, username);

    if (!user) {
      logActivity(null, username || 'unknown', 'LOGIN_FAILED', 'user', null, 'Invalid credentials', req);
      return res.status(401).json({ error: 'Invalid username or password.' });
    }

    const isValid = bcrypt.compareSync(password, user.password_hash);
    if (!isValid) {
      logActivity(null, user.username, 'LOGIN_FAILED', 'user', user.id, 'Invalid password', req);
      return res.status(401).json({ error: 'Invalid username or password.' });
    }

    const token = generateToken(user);

    logActivity(user.id, user.username, 'LOGIN_SUCCESS', 'user', user.id, 'Successful login', req);

    res.json({
      message: 'Login successful',
      token,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        full_name: user.full_name,
        role: user.role,
        must_change_password: Boolean(user.must_change_password)
      }
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Internal server error.' });
  }
};

exports.register = (req, res) => {
  try {
    const { full_name, username, email, password, confirm_password } = req.body;

    if (!full_name || !username || !email || !password || !confirm_password) {
      return res.status(400).json({ error: 'All fields are required.' });
    }

    if (password !== confirm_password) {
      return res.status(400).json({ error: 'Passwords do not match.' });
    }

    if (password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters.' });
    }

    const existingUser = db.prepare('SELECT id FROM users WHERE username = ? OR email = ?').get(username, email);
    if (existingUser) {
      return res.status(409).json({ error: 'Username or email already exists.' });
    }

    const saltRounds = parseInt(process.env.BCRYPT_SALT_ROUNDS) || 12;
    const passwordHash = bcrypt.hashSync(password, saltRounds);

    const stmt = db.prepare(
      'INSERT INTO users (full_name, username, email, password_hash, role, must_change_password, is_active) VALUES (?, ?, ?, ?, ?, 0, 1)'
    );
    const result = stmt.run(full_name, username, email, passwordHash, 'hr_payroll_staff');

    logActivity(result.lastInsertRowid, username, 'USER_REGISTERED', 'user', result.lastInsertRowid, 'New user registered', req);

    res.status(201).json({
      message: 'Registration successful. Please login.',
      userId: result.lastInsertRowid
    });
  } catch (err) {
    console.error('Register error:', err);
    res.status(500).json({ error: 'Internal server error.' });
  }
};

exports.me = (req, res) => {
  try {
    const user = db.prepare(
      'SELECT id, username, email, full_name, role, is_active, must_change_password, created_at FROM users WHERE id = ?'
    ).get(req.user.id);

    if (!user) {
      return res.status(404).json({ error: 'User not found.' });
    }

    res.json({
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        full_name: user.full_name,
        role: user.role,
        is_active: Boolean(user.is_active),
        must_change_password: Boolean(user.must_change_password),
        created_at: user.created_at
      }
    });
  } catch (err) {
    console.error('Me error:', err);
    res.status(500).json({ error: 'Internal server error.' });
  }
};

exports.changePassword = (req, res) => {
  try {
    const { current_password, new_password } = req.body;

    if (!current_password || !new_password) {
      return res.status(400).json({ error: 'Current password and new password are required.' });
    }

    if (new_password.length < 6) {
      return res.status(400).json({ error: 'New password must be at least 6 characters.' });
    }

    const user = db.prepare('SELECT password_hash FROM users WHERE id = ?').get(req.user.id);
    if (!user) {
      return res.status(404).json({ error: 'User not found.' });
    }

    const isValid = bcrypt.compareSync(current_password, user.password_hash);
    if (!isValid) {
      return res.status(401).json({ error: 'Current password is incorrect.' });
    }

    const saltRounds = parseInt(process.env.BCRYPT_SALT_ROUNDS) || 12;
    const newHash = bcrypt.hashSync(new_password, saltRounds);

    db.prepare('UPDATE users SET password_hash = ?, must_change_password = 0, updated_at = CURRENT_TIMESTAMP WHERE id = ?')
      .run(newHash, req.user.id);

    logActivity(req.user.id, req.user.username, 'PASSWORD_CHANGED', 'user', req.user.id, 'Password changed', req);

    res.json({ message: 'Password changed successfully.' });
  } catch (err) {
    console.error('Change password error:', err);
    res.status(500).json({ error: 'Internal server error.' });
  }
};

exports.logout = (req, res) => {
  try {
    if (req.user) {
      logActivity(req.user.id, req.user.username, 'LOGOUT', 'user', req.user.id, 'User logged out', req);
    }
    res.json({ message: 'Logged out successfully.' });
  } catch (err) {
    res.status(500).json({ error: 'Internal server error.' });
  }
};
