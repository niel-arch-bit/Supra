const path = require('path');
const fs = require('fs');
const initSqlJs = require('sql.js');
const { DB_PATH } = require('../config/storage');

let dbInstance = null;
let sql = null;

// Initialize sql.js and database
async function initDb() {
  sql = await initSqlJs();
  
  let db;
  if (fs.existsSync(DB_PATH)) {
    const fileBuffer = fs.readFileSync(DB_PATH);
    db = new sql.Database(fileBuffer);
  } else {
    db = new sql.Database();
  }
  
  db.exec('PRAGMA foreign_keys = ON;');
  
  // Auto-save after every write operation
  const originalRun = db.run.bind(db);
  db.run = function(sql, params) {
    const result = originalRun(sql, params);
    saveDb(db);
    return result;
  };
  
  dbInstance = db;
  return db;
}

function saveDb(db) {
  try {
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);
  } catch (err) {
    console.error('Failed to save database:', err.message);
  }
}

function getDb() {
  if (!dbInstance) {
    throw new Error('Database not initialized. Call initDb() first.');
  }
  return dbInstance;
}

function closeDb() {
  if (dbInstance) {
    saveDb(dbInstance);
    dbInstance.close();
    dbInstance = null;
  }
}

module.exports = { initDb, getDb, closeDb, saveDb };
