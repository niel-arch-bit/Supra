const Database = require('better-sqlite3');
const { logActivity } = require('../middleware/activityLogger');

const { DB_PATH } = require('../config/storage');
const db = new Database(DB_PATH);
db.pragma('foreign_keys = ON');

exports.recordAttendance = (req, res) => {
  try {
    const { employee_id, action } = req.body;

    if (!employee_id || !action) {
      return res.status(400).json({ error: 'Employee ID and action are required.' });
    }

    if (!['time_in', 'time_out'].includes(action)) {
      return res.status(400).json({ error: 'Invalid action. Must be time_in or time_out.' });
    }

    const today = new Date().toISOString().split('T')[0];
    const now = new Date();
    const currentTime = now.toTimeString().split(' ')[0];

    const employee = db.prepare('SELECT * FROM employees WHERE id = ?').get(employee_id);
    if (!employee) {
      return res.status(404).json({ error: 'Employee not found.' });
    }

    let attendance = db.prepare('SELECT * FROM attendance WHERE employee_id = ? AND attendance_date = ?').get(employee_id, today);

    if (!attendance) {
      const stmt = db.prepare(`
        INSERT INTO attendance (employee_id, attendance_date, time_in, time_out, total_hours, status, created_by)
        VALUES (?, ?, ?, ?, 0, 'Present', ?)
      `);
      const timeIn = action === 'time_in' ? currentTime : null;
      const timeOut = action === 'time_out' ? currentTime : null;
      const result = stmt.run(employee_id, today, timeIn, timeOut, req.user.id);
      attendance = { id: result.lastInsertRowid, employee_id, attendance_date: today, time_in: timeIn, time_out: timeOut };
    } else {
      if (action === 'time_in' && attendance.time_in) {
        return res.status(400).json({ error: 'Time in already recorded for today.' });
      }
      if (action === 'time_out' && attendance.time_out) {
        return res.status(400).json({ error: 'Time out already recorded for today.' });
      }

      const updateData = {};
      if (action === 'time_in') updateData.time_in = currentTime;
      if (action === 'time_out') updateData.time_out = currentTime;

      if (attendance.time_in || updateData.time_in) {
        const timeIn = updateData.time_in || attendance.time_in;
        const timeOut = updateData.time_out || attendance.time_out;
        if (timeIn && timeOut) {
          const tIn = new Date(`1970-01-01T${timeIn}Z`);
          const tOut = new Date(`1970-01-01T${timeOut}Z`);
          const diffMs = tOut - tIn;
          const diffHours = diffMs / (1000 * 60 * 60);
          updateData.total_hours = Math.round(diffHours * 100) / 100;
        }
      }

      const setClause = Object.keys(updateData).map(key => `${key} = ?`).join(', ');
      const values = Object.values(updateData);
      values.push(req.user.id, today);

      db.prepare(`UPDATE attendance SET ${setClause}, updated_at = CURRENT_TIMESTAMP WHERE employee_id = ? AND attendance_date = ?`).run(...values);
    }

    logActivity(req.user.id, req.user.username, 'ATTENDANCE_RECORDED', 'attendance', attendance.id,
      `${action.replace('_', ' ')} for employee ${employee.employee_id}`, req);

    res.json({ message: `${action.replace('_', ' ')} recorded successfully.`, attendance });
  } catch (err) {
    console.error('Record attendance error:', err);
    res.status(500).json({ error: 'Internal server error.' });
  }
};

exports.getAll = (req, res) => {
  try {
    const { employee_id, department, start_date, end_date, page = 1, limit = 50 } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);

    let query = `
      SELECT a.*, e.employee_id, e.first_name, e.last_name, d.name as department_name
      FROM attendance a
      JOIN employees e ON a.employee_id = e.id
      LEFT JOIN departments d ON e.department_id = d.id
      WHERE 1=1
    `;
    const params = [];

    if (employee_id) {
      query += ` AND e.id = ?`;
      params.push(employee_id);
    }
    if (department) {
      query += ` AND e.department_id = ?`;
      params.push(department);
    }
    if (start_date) {
      query += ` AND a.attendance_date >= ?`;
      params.push(start_date);
    }
    if (end_date) {
      query += ` AND a.attendance_date <= ?`;
      params.push(end_date);
    }

    query += ` ORDER BY a.attendance_date DESC, e.employee_id ASC LIMIT ? OFFSET ?`;
    params.push(parseInt(limit), offset);

    const records = db.prepare(query).all(params);
    res.json({ records });
  } catch (err) {
    console.error('Get attendance error:', err);
    res.status(500).json({ error: 'Internal server error.' });
  }
};

exports.getSummary = (req, res) => {
  try {
    const { employee_id, start_date, end_date } = req.query;

    let query = `
      SELECT a.*, e.employee_id, e.first_name, e.last_name
      FROM attendance a
      JOIN employees e ON a.employee_id = e.id
      WHERE 1=1
    `;
    const params = [];

    if (employee_id) {
      query += ` AND e.id = ?`;
      params.push(employee_id);
    }
    if (start_date) {
      query += ` AND a.attendance_date >= ?`;
      params.push(start_date);
    }
    if (end_date) {
      query += ` AND a.attendance_date <= ?`;
      params.push(end_date);
    }

    query += ` ORDER BY a.attendance_date DESC`;

    const records = db.prepare(query).all(params);
    res.json({ records });
  } catch (err) {
    console.error('Get attendance summary error:', err);
    res.status(500).json({ error: 'Internal server error.' });
  }
};

exports.update = (req, res) => {
  try {
    const { time_in, time_out, status, notes } = req.body;

    const existing = db.prepare('SELECT * FROM attendance WHERE id = ?').get(req.params.id);
    if (!existing) {
      return res.status(404).json({ error: 'Attendance record not found.' });
    }

    let total_hours = existing.total_hours;
    if (time_in && time_out) {
      const tIn = new Date(`1970-01-01T${time_in}Z`);
      const tOut = new Date(`1970-01-01T${time_out}Z`);
      const diffMs = tOut - tIn;
      total_hours = Math.round((diffMs / (1000 * 60 * 60)) * 100) / 100;
    }

    db.prepare(`
      UPDATE attendance SET
        time_in = COALESCE(?, time_in),
        time_out = COALESCE(?, time_out),
        total_hours = ?,
        status = COALESCE(?, status),
        notes = COALESCE(?, notes),
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(time_in, time_out, total_hours, status, notes, req.params.id);

    logActivity(req.user.id, req.user.username, 'ATTENDANCE_CORRECTED', 'attendance', req.params.id,
      'Corrected attendance record', req);

    res.json({ message: 'Attendance updated successfully.' });
  } catch (err) {
    console.error('Update attendance error:', err);
    res.status(500).json({ error: 'Internal server error.' });
  }
};
