import React, { useState, useEffect } from 'react';
import { toast } from 'react-hot-toast';
import api from '../services/api';
import { UserPlus, Trash2, Key } from 'lucide-react';

export default function UserManagement() {
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({ full_name: '', username: '', email: '', password: '', role: 'hr_payroll_staff' });

  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = async () => {
    setLoading(true);
    try {
      const res = await api.get('/users/');
      setUsers(res.data.users);
    } catch (err) {
      toast.error('Failed to load users');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.post('/users/', formData);
      toast.success('User created successfully!');
      setShowForm(false);
      loadUsers();
    } catch (err: any) {
      toast.error(err.response?.data?.error || 'Failed to create user.');
    }
  };

  const resetPassword = async (id: number) => {
    const newPassword = window.prompt('Enter new temporary password:');
    if (!newPassword) return;
    try {
      await api.post(`/users/${id}/reset-password`, { new_password: newPassword });
      toast.success('Password reset successfully!');
    } catch (err: any) {
      toast.error(err.response?.data?.error || 'Failed to reset password.');
    }
  };

  const deactivateUser = async (id: number) => {
    if (!window.confirm('Deactivate this user?')) return;
    try {
      await api.patch(`/users/${id}/deactivate`);
      toast.success('User deactivated');
      loadUsers();
    } catch (err) {
      toast.error('Failed to deactivate user');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">User Management</h1>
          <p className="text-gray-500">Administrator only - Manage system users</p>
        </div>
        <button
          onClick={() => setShowForm(true)}
          className="supra-btn-primary flex items-center gap-2"
        >
          <UserPlus className="w-4 h-4" />
          Add User
        </button>
      </div>

      {showForm && (
        <div className="supra-card p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Add New User</h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
                <input
                  value={formData.full_name}
                  onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                  className="supra-input"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Username</label>
                <input
                  value={formData.username}
                  onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                  className="supra-input"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="supra-input"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Password</label>
                <input
                  type="password"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="supra-input"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Role</label>
                <select
                  value={formData.role}
                  onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                  className="supra-input"
                >
                  <option value="administrator">Administrator</option>
                  <option value="hr_payroll_staff">HR/Payroll Staff</option>
                </select>
              </div>
              <div className="col-span-1">
                <button type="submit" className="supra-btn-primary w-auto px-6 py-3">
                  Create User
                </button>
                <button
                  type="button"
                  onClick={() => setShowForm(false)}
                  className="ml-3 px-6 py-3 border border-gray-200 rounded-xl text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
              </div>
            </div>
          </form>
        </div>
      )}

      <div className="supra-card p-6">
        <div className="overflow-x-auto">
          <table className="supra-table">
            <thead>
              <tr>
                <th>Username</th>
                <th>Full Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Status</th>
                <th className="text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={6} className="text-center py-8 text-gray-500">Loading...</td></tr>
              ) : users.length === 0 ? (
                <tr><td colSpan={6} className="text-center py-8 text-gray-500">No users found.</td></tr>
              ) : (
                users.map((u) => (
                  <tr key={u.id} className="hover:bg-gray-50/50 transition-colors">
                    <td className="font-medium text-gray-900">{u.username}</td>
                    <td className="text-gray-700">{u.full_name}</td>
                    <td className="text-gray-700 text-sm">{u.email}</td>
                    <td>
                      <span className={`supra-badge ${u.role === 'administrator' ? 'bg-supra-red-100 text-supra-red-700' : 'bg-blue-100 text-blue-700'}`}>
                        {u.role.replace('_', ' ')}
                      </span>
                    </td>
                    <td>
                      <span className={`supra-badge ${u.is_active ? 'badge-present' : 'badge-absent'}`}>
                        {u.is_active ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                    <td className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button onClick={() => resetPassword(u.id)} className="text-blue-600 hover:text-blue-800" title="Reset Password">
                          <Key className="w-4 h-4" />
                        </button>
                        <button onClick={() => deactivateUser(u.id)} className="text-red-600 hover:text-red-800" title="Deactivate">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
