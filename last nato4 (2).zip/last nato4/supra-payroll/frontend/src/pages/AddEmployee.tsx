import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-hot-toast';
import api from '../services/api';
import { ArrowLeft, Plus, Loader2 } from 'lucide-react';
import type { Department } from '../types';

export default function AddEmployee() {
  const navigate = useNavigate();
  const [departments, setDepartments] = useState<Department[]>([]);
  const [formData, setFormData] = useState({
    employee_id: '',
    first_name: '',
    middle_name: '',
    last_name: '',
    gender: '',
    date_of_birth: '',
    contact_number: '',
    email: '',
    home_address: '',
    department_id: '',
    job_position: '',
    employment_status: 'Regular',
    date_hired: '',
    basic_monthly_salary: ''
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    api.get('/employees/departments')
      .then((res) => setDepartments(res.data.departments))
      .catch(() => toast.error('Failed to load departments'));
  }, []);

  const generateEmployeeId = () => {
    const id = `SUP-${Math.floor(1000 + Math.random() * 9000)}`;
    setFormData(prev => ({ ...prev, employee_id: id }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await api.post('/employees/', formData);
      toast.success('Employee created successfully!');
      navigate('/employees');
    } catch (err: any) {
      toast.error(err.response?.data?.error || 'Failed to create employee.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <button onClick={() => navigate('/employees')} className="flex items-center gap-2 text-gray-600 hover:text-supra-red-600 mb-4">
            <ArrowLeft className="w-4 h-4" />
            Back to Employee List
          </button>
          <h1 className="text-2xl font-bold text-gray-900">Add New Employee</h1>
          <p className="text-gray-500">Enter employee details below</p>
        </div>
        <button onClick={generateEmployeeId} className="supra-btn-secondary flex items-center gap-2">
          <Plus className="w-4 h-4" />
          Generate ID
        </button>
      </div>

      <div className="supra-card p-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="col-span-1">
              <label className="block text-sm font-medium text-gray-700 mb-2">Employee ID</label>
              <div className="relative">
                <input
                  type="text"
                  value={formData.employee_id}
                  onChange={(e) => setFormData({ ...formData, employee_id: e.target.value })}
                  className="supra-input"
                  placeholder="Auto-generated"
                  required
                />
                <button
                  type="button"
                  onClick={generateEmployeeId}
                  className="absolute right-2 top-2 text-xs bg-supra-red-600 text-white px-2 py-1 rounded hover:bg-supra-red-700"
                >
                  Generate
                </button>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">First Name</label>
              <input
                type="text"
                value={formData.first_name}
                onChange={(e) => setFormData({ ...formData, first_name: e.target.value })}
                className="supra-input"
                placeholder="First name"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Middle Name</label>
              <input
                type="text"
                value={formData.middle_name}
                onChange={(e) => setFormData({ ...formData, middle_name: e.target.value })}
                className="supra-input"
                placeholder="Middle name"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Last Name</label>
              <input
                type="text"
                value={formData.last_name}
                onChange={(e) => setFormData({ ...formData, last_name: e.target.value })}
                className="supra-input"
                placeholder="Last name"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Gender</label>
              <select value={formData.gender} onChange={(e) => setFormData({ ...formData, gender: e.target.value })} className="supra-input">
                <option value="">Select gender</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Date of Birth</label>
              <input type="date" value={formData.date_of_birth} onChange={(e) => setFormData({ ...formData, date_of_birth: e.target.value })} className="supra-input" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Contact Number</label>
              <input type="tel" value={formData.contact_number} onChange={(e) => setFormData({ ...formData, contact_number: e.target.value })} className="supra-input" placeholder="Phone number" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
              <input type="email" value={formData.email} onChange={(e) => setFormData({ ...formData, email: e.target.value })} className="supra-input" placeholder="email@company.com" />
            </div>
            <div className="col-span-1">
              <label className="block text-sm font-medium text-gray-700 mb-2">Home Address</label>
              <textarea value={formData.home_address} onChange={(e) => setFormData({ ...formData, home_address: e.target.value })} className="supra-input" rows={3} placeholder="Home address" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Department</label>
              <select value={formData.department_id} onChange={(e) => setFormData({ ...formData, department_id: e.target.value })} className="supra-input">
                <option value="">Select department</option>
                {departments.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Job Position</label>
              <input type="text" value={formData.job_position} onChange={(e) => setFormData({ ...formData, job_position: e.target.value })} className="supra-input" placeholder="Job title" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Employment Status</label>
              <select value={formData.employment_status} onChange={(e) => setFormData({ ...formData, employment_status: e.target.value })} className="supra-input">
                <option value="Regular">Regular</option>
                <option value="Probationary">Probationary</option>
                <option value="Contractual">Contractual</option>
                <option value="Casual">Casual</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Date Hired</label>
              <input type="date" value={formData.date_hired} onChange={(e) => setFormData({ ...formData, date_hired: e.target.value })} className="supra-input" required />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Basic Monthly Salary (₱)</label>
              <input type="number" value={formData.basic_monthly_salary} onChange={(e) => setFormData({ ...formData, basic_monthly_salary: e.target.value })} className="supra-input" placeholder="0.00" required />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="supra-btn-primary w-full flex items-center justify-center gap-2 disabled:opacity-60"
          >
            {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : 'Save Employee Record'}
          </button>
        </form>
      </div>
    </div>
  );
}
