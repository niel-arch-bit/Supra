require('dotenv').config();
const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');
const { spawnSync } = require('child_process');
const { DB_PATH } = require('./config/storage');

const PORT = process.env.PORT || 5000;

// Initialize a new persistent database once, on the first service start.
if (!fs.existsSync(DB_PATH)) {
  const setupPath = path.join(__dirname, 'database/setup.js');
  const setup = spawnSync(process.execPath, [setupPath], { stdio: 'inherit', env: process.env });
  if (setup.error) throw setup.error;
  if (setup.status !== 0) throw new Error(`Database setup failed with exit code ${setup.status}`);
}

const db = new Database(DB_PATH);
db.pragma('foreign_keys = ON');
db.close();

// Load the API only after the first-run setup has created its schema.
const app = require('./app');

app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 SUPRA Employee Management and Payroll System`);
  console.log(`📡 Server running on port ${PORT}`);
  console.log(`🌐 Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log(`📊 Database: ${DB_PATH}`);
  console.log(`🔗 API: http://localhost:${PORT}/api`);
});
