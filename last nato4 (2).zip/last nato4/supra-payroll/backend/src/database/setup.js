const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '../../.env') });
const fs = require('fs');
const bcrypt = require('bcryptjs');
const Database = require('better-sqlite3');
const { DB_PATH, UPLOAD_PATH } = require('../config/storage');

const SCHEMA_PATH = path.join(__dirname, 'schema.sql');

// Ensure directories exist
const dbDir = path.dirname(DB_PATH);
fs.mkdirSync(dbDir, { recursive: true });
fs.mkdirSync(UPLOAD_PATH, { recursive: true });

const db = new Database(DB_PATH);
db.pragma('foreign_keys = ON');

// Read and execute schema
const schema = fs.readFileSync(SCHEMA_PATH, 'utf8');
db.exec(schema);
console.log('✓ Database schema created');

// Insert default departments
const departments = [
  { name: 'Human Resources', description: 'Human Resources Department' },
  { name: 'Accounting', description: 'Accounting and Finance Department' },
  { name: 'Operations', description: 'Operations Department' },
  { name: 'IT Department', description: 'Information Technology Department' },
  { name: 'Sales', description: 'Sales and Marketing Department' },
  { name: 'Admin', description: 'Administration Department' }
];

const insertDept = db.prepare('INSERT OR IGNORE INTO departments (name, description) VALUES (?, ?)');
departments.forEach(d => insertDept.run(d.name, d.description));
console.log('✓ Default departments inserted');

const seedDemoData = process.env.NODE_ENV === 'development' || process.env.SEED_DEMO_DATA === 'true';

// Clearly marked fictional sample employees help demonstrate the dashboard and
// employee workflow without adding any real personal records.
if (seedDemoData) {
  const demoEmployees = [
    { id: 'DEMO-001', first: 'Saraza', last: '', gender: 'Other', dob: '1994-02-14', email: 'saraza@example.com', department: 'Human Resources', position: 'HR Coordinator', hired: '2023-06-12', salary: 38000 },
    { id: 'DEMO-002', first: 'Sampayan', last: '', gender: 'Other', dob: '1992-09-03', email: 'sampayan@example.com', department: 'Accounting', position: 'Payroll Assistant', hired: '2022-11-07', salary: 42000 },
    { id: 'DEMO-003', first: 'Santos', last: '', gender: 'Other', dob: '1996-04-21', email: 'santos@example.com', department: 'Operations', position: 'Operations Associate', hired: '2024-01-15', salary: 35000 },
    { id: 'DEMO-004', first: 'Sison', last: '', gender: 'Other', dob: '1990-12-08', email: 'sison@example.com', department: 'IT Department', position: 'IT Support Specialist', hired: '2021-08-02', salary: 48000 }
  ];
  const upsertEmployee = db.prepare(`
    INSERT OR IGNORE INTO employees
      (employee_id, first_name, last_name, gender, date_of_birth, email, home_address,
       department_id, job_position, employment_status, date_hired, basic_monthly_salary)
    VALUES (?, ?, ?, ?, ?, ?, 'Fictional sample record', ?, ?, 'Regular', ?, ?)
  `);
  const updateDemoEmployee = db.prepare(`
    UPDATE employees SET
      first_name = ?, last_name = ?, gender = ?, date_of_birth = ?, email = ?,
      home_address = 'Fictional sample record', department_id = ?, job_position = ?,
      employment_status = 'Regular', date_hired = ?, basic_monthly_salary = ?,
      is_archived = 0, updated_at = CURRENT_TIMESTAMP
    WHERE employee_id = ?
  `);

  for (const employee of demoEmployees) {
    const department = db.prepare('SELECT id FROM departments WHERE name = ?').get(employee.department);
    upsertEmployee.run(
      employee.id, employee.first, employee.last, employee.gender, employee.dob,
      employee.email, department?.id ?? null, employee.position, employee.hired, employee.salary
    );
    updateDemoEmployee.run(
      employee.first, employee.last, employee.gender, employee.dob, employee.email,
      department?.id ?? null, employee.position, employee.hired, employee.salary, employee.id
    );
  }
  // Retire the old fifth fictional sample employee so the demo list matches the four requested names.
  db.prepare("UPDATE employees SET is_archived = 1, updated_at = CURRENT_TIMESTAMP WHERE employee_id = 'DEMO-005'").run();
  console.log('Fictional demo employees inserted (development only)');
}

// Insert payroll settings
const settings = [
  { key: 'overtime_rate_multiplier', value: '1.25', description: 'Overtime rate multiplier for hours beyond 8 per day' },
  { key: 'night_differential_rate', value: '0.10', description: 'Night differential rate (10% of hourly rate)' },
  { key: 'ssc_employee_rate', value: '4.5', description: 'SSC employee contribution rate (percentage)' },
  { key: 'philhealth_rate', value: '0.05', description: 'PhilHealth contribution rate' },
  { key: 'pagibig_contribution', value: '100.00', description: 'Pag-IBIG monthly contribution' },
  { key: 'tax_bracket_1_threshold', value: '20833', description: 'First tax bracket threshold (monthly)' },
  { key: 'tax_bracket_1_rate', value: '0.00', description: 'First tax bracket rate' },
  { key: 'tax_bracket_2_threshold', value: '33333', description: 'Second tax bracket threshold (monthly)' },
  { key: 'tax_bracket_2_rate', value: '0.20', description: 'Second tax bracket rate' },
  { key: 'tax_bracket_3_threshold', value: '66667', description: 'Third tax bracket threshold (monthly)' },
  { key: 'tax_bracket_3_rate', value: '0.25', description: 'Third tax bracket rate' },
  { key: 'tax_bracket_4_threshold', value: '166667', description: 'Fourth tax bracket threshold (monthly)' },
  { key: 'tax_bracket_4_rate', value: '0.30', description: 'Fourth tax bracket rate' }
];

const insertSetting = db.prepare('INSERT OR IGNORE INTO payroll_settings (setting_key, setting_value, description) VALUES (?, ?, ?)');
settings.forEach(s => insertSetting.run(s.key, s.value, s.description));
console.log('✓ Payroll settings inserted');

// Insert initial demo users
const saltRounds = parseInt(process.env.BCRYPT_SALT_ROUNDS) || 12;

const demoUsers = [
  {
    full_name: 'Tan',
    username: 'tan',
    email: 'tan@example.com',
    password: 'Tan123',
    role: 'administrator',
    must_change_password: 0
  },
  {
    full_name: 'Saraza',
    username: 'saraza',
    email: 'saraza@example.com',
    password: 'Saraza123',
    role: 'hr_payroll_staff',
    must_change_password: 0
  },
  {
    full_name: 'Santos',
    username: 'santos',
    email: 'santos@example.com',
    password: 'Santos123',
    role: 'hr_payroll_staff',
    must_change_password: 0
  },
  {
    full_name: 'Sampayan',
    username: 'sampayan',
    email: 'sampayan@example.com',
    password: 'Sampayan123',
    role: 'hr_payroll_staff',
    must_change_password: 0
  },
  {
    full_name: 'Sison',
    username: 'sison',
    email: 'sison@example.com',
    password: 'Sison123',
    role: 'hr_payroll_staff',
    must_change_password: 0
  }
];

const checkUser = db.prepare('SELECT id, username, email, password_hash FROM users WHERE username = ? OR email = ?');
const insertUser = db.prepare(
  'INSERT INTO users (full_name, username, email, password_hash, role, must_change_password, is_active) VALUES (?, ?, ?, ?, ?, ?, 1)'
);
const repairLegacyUser = db.prepare(
  'UPDATE users SET password_hash = ?, must_change_password = 0, updated_at = CURRENT_TIMESTAMP WHERE id = ?'
);

for (const user of demoUsers) {
  const existing = checkUser.get(user.username, user.email);
  if (!existing) {
    const passwordHash = bcrypt.hashSync(user.password, saltRounds);
    insertUser.run(user.full_name, user.username, user.email, passwordHash, user.role, user.must_change_password);
    console.log(`✓ Demo user created: ${user.username} (${user.role})`);
  } else {
    // Older project copies seeded every demo account with Practice123. Repair
    // only those untouched legacy accounts; preserve any password a user changed.
    if (
      existing.username === user.username &&
      existing.email === user.email &&
      bcrypt.compareSync('Practice123', existing.password_hash)
    ) {
      const passwordHash = bcrypt.hashSync(user.password, saltRounds);
      repairLegacyUser.run(passwordHash, existing.id);
      console.log(`✓ Demo user password repaired: ${user.username}`);
      continue;
    }
    console.log(`- Demo user already exists: ${user.username}`);
  }
}

// Password changes are available from the authenticated profile screen.
db.prepare("UPDATE users SET must_change_password = 0 WHERE username IN ('tan', 'saraza', 'santos', 'sampayan', 'sison')").run();

console.log('\n✅ Database setup complete!');
console.log('📍 Database file:', DB_PATH);
console.log('👥 Demo accounts:');
if (process.env.NODE_ENV !== 'production') {
  console.log('   tan / Tan123 (Administrator)');
  console.log('   saraza / Saraza123 (HR/Payroll Staff)');
  console.log('   santos / Santos123 (HR/Payroll Staff)');
  console.log('   sampayan / Sampayan123 (HR/Payroll Staff)');
  console.log('   sison / Sison123 (HR/Payroll Staff)');
}
console.log('Users can change their password from the Profile page.');

if (seedDemoData) {
  const admin = db.prepare("SELECT id FROM users WHERE username = 'tan'").get();
  const demoStaff = db.prepare(`
    SELECT id, employee_id, first_name, last_name, basic_monthly_salary
    FROM employees WHERE employee_id LIKE 'DEMO-%' AND is_archived = 0
    ORDER BY employee_id
  `).all();

  if (admin && demoStaff.length) {
    const now = new Date();
    const previousMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    const toDateString = (date) => [
      date.getFullYear(),
      String(date.getMonth() + 1).padStart(2, '0'),
      String(date.getDate()).padStart(2, '0')
    ].join('-');
    const periodStart = toDateString(previousMonth);
    const periodEnd = toDateString(new Date(previousMonth.getFullYear(), previousMonth.getMonth(), 15));
    const insertPayroll = db.prepare(`
      INSERT OR IGNORE INTO payroll
        (employee_id, period_start, period_end, basic_pay, total_earnings, net_pay,
         status, processed_by, approved_by, processed_at, approved_at)
      VALUES (?, ?, ?, ?, ?, ?, 'Confirmed', ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
    `);
    const findPayroll = db.prepare(
      'SELECT id, employee_id, period_start, period_end, net_pay FROM payroll WHERE employee_id = ? AND period_start = ? AND period_end = ?'
    );
    const insertPayslip = db.prepare(`
      INSERT OR IGNORE INTO payslips (payroll_id, employee_id, period_start, period_end, net_pay, generated_by)
      VALUES (?, ?, ?, ?, ?, ?)
    `);

    const demoUploadDir = path.join(UPLOAD_PATH, 'demo-files');
    fs.mkdirSync(demoUploadDir, { recursive: true });

    // Remove only the exact sample artifacts created for the retired fifth demo record.
    const retiredEmployee = db.prepare("SELECT id FROM employees WHERE employee_id = 'DEMO-005'").get();
    if (retiredEmployee) {
      const retiredFile = db.prepare(`
        SELECT id, file_path FROM employee_201_files
        WHERE employee_id = ? AND document_name = 'Fictional demo employee summary'
          AND file_name = 'DEMO-005-sample-record.txt'
      `).get(retiredEmployee.id);
      if (retiredFile) {
        db.prepare('DELETE FROM employee_201_files WHERE id = ?').run(retiredFile.id);
        if (path.dirname(retiredFile.file_path) === demoUploadDir && path.basename(retiredFile.file_path) === 'DEMO-005-sample-record.txt') {
          fs.rmSync(retiredFile.file_path, { force: true });
        }
      }

      const retiredPayroll = db.prepare(`
        SELECT id FROM payroll
        WHERE employee_id = ? AND period_start = ? AND period_end = ?
          AND status = 'Confirmed' AND processed_by = ? AND approved_by = ?
      `).get(retiredEmployee.id, periodStart, periodEnd, admin.id, admin.id);
      if (retiredPayroll) {
        db.prepare('DELETE FROM payslips WHERE payroll_id = ?').run(retiredPayroll.id);
        db.prepare('DELETE FROM payroll WHERE id = ?').run(retiredPayroll.id);
      }
    }

    for (const employee of demoStaff) {
      const sampleBasicPay = Math.round((Number(employee.basic_monthly_salary) / 2) * 100) / 100;
      insertPayroll.run(employee.id, periodStart, periodEnd, sampleBasicPay, sampleBasicPay, sampleBasicPay, admin.id, admin.id);
      const payroll = findPayroll.get(employee.id, periodStart, periodEnd);
      if (payroll) {
        insertPayslip.run(payroll.id, employee.id, periodStart, periodEnd, payroll.net_pay, admin.id);
      }
    }

    const findDemoFile = db.prepare(
      'SELECT id FROM employee_201_files WHERE employee_id = ? AND document_name = ?'
    );
    const insertDemoFile = db.prepare(`
      INSERT INTO employee_201_files
        (employee_id, document_name, document_category, file_name, file_path, file_type, file_size, uploaded_by)
      VALUES (?, ?, 'Other Employment Documents', ?, ?, 'text/plain', ?, ?)
    `);

    for (const employee of demoStaff) {
      const documentName = 'Fictional demo employee summary';
      const filename = `${employee.employee_id}-sample-record.txt`;
      const filePath = path.join(demoUploadDir, filename);
      const content = [
        'SUPRA Employee Management and Payroll System',
        'Fictional sample document for interface demonstration only.',
        `Employee ID: ${employee.employee_id}`,
        `Name: ${employee.first_name} ${employee.last_name}`,
        'This file contains no real employee information.'
      ].join('\n');
      fs.writeFileSync(filePath, content, 'utf8');

      if (!findDemoFile.get(employee.id, documentName)) {
        insertDemoFile.run(employee.id, documentName, filename, filePath, Buffer.byteLength(content), admin.id);
      }
    }
  }

    console.log('Fictional demo payslips and employee files inserted for Saraza, Sampayan, Santos, and Sison');
}

db.close();
