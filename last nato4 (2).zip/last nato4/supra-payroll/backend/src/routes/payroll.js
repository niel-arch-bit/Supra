const express = require('express');
const router = express.Router();
const payrollController = require('../controllers/payrollController');
const { authenticateToken, requireActiveUser, authorizeRoles } = require('../middleware/auth');

router.post('/process', authenticateToken, requireActiveUser, authorizeRoles('administrator', 'hr_payroll_staff'), payrollController.process);
router.get('/', authenticateToken, requireActiveUser, payrollController.getAll);
router.get('/settings', authenticateToken, requireActiveUser, payrollController.getSettings);
router.get('/:id', authenticateToken, requireActiveUser, payrollController.getById);
router.patch('/:id/confirm', authenticateToken, requireActiveUser, authorizeRoles('administrator', 'hr_payroll_staff'), payrollController.confirm);
router.patch('/:id/pay', authenticateToken, requireActiveUser, authorizeRoles('administrator', 'hr_payroll_staff'), payrollController.pay);
router.post('/settings', authenticateToken, requireActiveUser, authorizeRoles('administrator'), payrollController.updateSetting);

module.exports = router;
