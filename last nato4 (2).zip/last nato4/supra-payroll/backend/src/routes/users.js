const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const { authenticateToken, requireActiveUser, authorizeRoles } = require('../middleware/auth');

router.get('/', authenticateToken, requireActiveUser, authorizeRoles('administrator'), userController.getAll);
router.post('/', authenticateToken, requireActiveUser, authorizeRoles('administrator'), userController.create);
router.put('/:id', authenticateToken, requireActiveUser, authorizeRoles('administrator'), userController.update);
router.post('/:id/reset-password', authenticateToken, requireActiveUser, authorizeRoles('administrator'), userController.resetPassword);
router.patch('/:id/deactivate', authenticateToken, requireActiveUser, authorizeRoles('administrator'), userController.deactivate);

module.exports = router;