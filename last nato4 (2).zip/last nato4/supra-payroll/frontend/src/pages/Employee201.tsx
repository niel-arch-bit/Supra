import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-hot-toast';
import api from '../services/api';
import { ArrowLeft, Upload, Download, Trash2 } from 'lucide-react';

export default function Employee201() {
  const navigate = useNavigate();
  const [files, setFiles] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [employeeFilter, setEmployeeFilter] = useState('');

  useEffect(() => {
    loadFiles();
  }, [employeeFilter]);

  const loadFiles = async () => {
    setLoading(true);
    try {
      const res = await api.get('/employee201/', { params: { employee_id: employeeFilter || undefined } });
      setFiles(res.data.files);
    } catch (err) {
      toast.error('Failed to load employee files');
    } finally {
      setLoading(false);
    }
  };

  const downloadFile = async (id: number, filename: string) => {
    try {
      const response = await api.get(`/employee201/download/${id}`, { responseType: 'blob' });
      const url = URL.createObjectURL(response.data);
      const anchor = document.createElement('a');
      anchor.href = url;
      anchor.download = filename;
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch {
      toast.error('Failed to download document');
    }
  };

  const deleteFile = async (id: number) => {
    if (!window.confirm('Delete this document?')) return;
    try {
      await api.delete(`/employee201/${id}`);
      toast.success('Document deleted');
      loadFiles();
    } catch (err) {
      toast.error('Failed to delete document');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <button onClick={() => navigate('/dashboard')} className="flex items-center gap-2 text-gray-600 hover:text-supra-red-600 mb-4">
            <ArrowLeft className="w-4 h-4" />
            Back to Dashboard
          </button>
          <h1 className="text-2xl font-bold text-gray-900">Employee 201 Files</h1>
          <p className="text-gray-500">Manage employee documents and records</p>
        </div>
        <button
          onClick={() => navigate('/employee201/upload')}
          className="supra-btn-primary flex items-center gap-2"
        >
          <Upload className="w-4 h-4" />
          Upload Document
        </button>
      </div>

      <div className="supra-card p-6">
        <div className="flex items-center gap-4 mb-6">
          <input
            type="text"
            value={employeeFilter}
            onChange={(e) => setEmployeeFilter(e.target.value)}
            placeholder="Search by employee name or ID"
            className="supra-input flex-1 max-w-md"
          />
        </div>

        <div className="overflow-x-auto">
          <table className="supra-table">
            <thead>
              <tr>
                <th>Employee</th>
                <th>Document Name</th>
                <th>Category</th>
                <th>Upload Date</th>
                <th>Uploaded By</th>
                <th className="text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={6} className="text-center py-8 text-gray-500">Loading...</td></tr>
              ) : files.length === 0 ? (
                <tr><td colSpan={6} className="text-center py-8 text-gray-500">No documents found.</td></tr>
              ) : (
                files.map((f) => (
                  <tr key={f.id} className="hover:bg-gray-50/50 transition-colors">
                    <td className="font-medium text-gray-900">{f.employee_id_str || f.employee_id}</td>
                    <td className="text-gray-700">{f.document_name}</td>
                    <td className="text-gray-700 text-sm">{f.document_category}</td>
                    <td className="text-gray-700 text-sm">{f.upload_date}</td>
                    <td className="text-gray-700 text-sm">{f.uploaded_by_name || 'Unknown'}</td>
                    <td className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button onClick={() => downloadFile(f.id, f.file_name)} className="text-blue-600 hover:text-blue-800" title="Download">
                          <Download className="w-4 h-4" />
                        </button>
                        <button onClick={() => deleteFile(f.id)} className="text-red-600 hover:text-red-800" title="Delete">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
