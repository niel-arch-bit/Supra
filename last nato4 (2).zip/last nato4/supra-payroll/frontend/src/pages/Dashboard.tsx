import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Activity, ArrowUpRight, Briefcase, Clock3, CreditCard, FileText, Folder, Users } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import api from '../services/api';
import type { ActivityLog, DashboardStats, Employee, Payroll } from '../types';

const emptyStats: DashboardStats = {
  total_employees: 0,
  present_today: 0,
  absent_today: 0,
  pending_payroll: 0,
  total_payroll_current_period: 0,
};

const modules = [
  { name: 'Manage employees', path: '/employees', description: 'View employee records', icon: Users },
  { name: 'Record attendance', path: '/attendance/record', description: 'Log time in and time out', icon: Clock3 },
  { name: 'Process payroll', path: '/payroll/process', description: 'Prepare payroll for a period', icon: CreditCard },
  { name: 'View payslips', path: '/payslip/view', description: 'Review employee payslips', icon: FileText },
  { name: 'Employee files', path: '/employee201', description: 'Manage employee documents', icon: Folder },
];

const money = new Intl.NumberFormat('en-PH', { style: 'currency', currency: 'PHP' });

function displayDate(value?: string | null) {
  if (!value) return '—';
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : date.toLocaleDateString('en-PH', { month: 'short', day: 'numeric', year: 'numeric' });
}

export default function Dashboard() {
  const { user } = useAuth();
  const [stats, setStats] = useState<DashboardStats>(emptyStats);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [payroll, setPayroll] = useState<Payroll[]>([]);
  const [activity, setActivity] = useState<ActivityLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [hasLoadError, setHasLoadError] = useState(false);

  useEffect(() => {
    let active = true;

    const loadDashboard = async () => {
      setLoading(true);
      const results = await Promise.allSettled([
        api.get('/employees/dashboard-stats'),
        api.get('/employees', { params: { limit: 5 } }),
        api.get('/payroll', { params: { limit: 5 } }),
      ]);

      if (!active) return;
      let failed = false;
      const [statsResult, employeesResult, payrollResult] = results;

      if (statsResult.status === 'fulfilled') setStats(statsResult.value.data);
      else failed = true;

      if (employeesResult.status === 'fulfilled') setEmployees(employeesResult.value.data.employees ?? []);
      else failed = true;

      if (payrollResult.status === 'fulfilled') setPayroll(payrollResult.value.data.records ?? []);
      else failed = true;

      if (user?.role === 'administrator') {
        const activityResult = await Promise.allSettled([
          api.get('/activity-logs', { params: { limit: 5 } }),
        ]);
        if (!active) return;
        if (activityResult[0].status === 'fulfilled') setActivity(activityResult[0].value.data.logs ?? []);
        else failed = true;
      }

      setHasLoadError(failed);
      setLoading(false);
    };

    void loadDashboard();
    return () => { active = false; };
  }, [user?.role]);

  const cards = [
    { label: 'Employees', value: stats.total_employees, detail: 'Active records', icon: Users, tone: 'bg-red-50 text-supra-red-600' },
    { label: 'Present today', value: stats.present_today, detail: 'Attendance records', icon: Clock3, tone: 'bg-emerald-50 text-emerald-700' },
    { label: 'Absent today', value: stats.absent_today, detail: 'Attendance records', icon: Briefcase, tone: 'bg-amber-50 text-amber-700' },
    { label: 'Pending payroll', value: stats.pending_payroll, detail: 'Draft payroll records', icon: CreditCard, tone: 'bg-blue-50 text-blue-700' },
    { label: 'Payroll this period', value: money.format(Number(stats.total_payroll_current_period) || 0), detail: 'Net pay in the active period', icon: CreditCard, tone: 'bg-gray-100 text-gray-700' },
  ];

  return (
    <div className="mx-auto max-w-7xl space-y-7">
      <header className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="text-sm font-medium text-supra-red-600">SUPRA EMPLOYEE MANAGEMENT</p>
          <h1 className="mt-1 text-2xl font-bold tracking-tight text-gray-900">Dashboard</h1>
          <p className="mt-1 text-sm text-gray-500">Welcome back, {user?.full_name || user?.username}.</p>
        </div>
        <p className="text-sm text-gray-500">{new Date().toLocaleDateString('en-PH', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })}</p>
      </header>

      {hasLoadError && (
        <div className="rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800" role="status">
          Some dashboard data could not be loaded. Check that the backend is running, then refresh this page.
        </div>
      )}

      <section className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-5" aria-label="Overview">
        {cards.map((card) => (
          <article key={card.label} className="rounded-2xl border border-gray-200 bg-white p-5 shadow-sm">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="text-sm font-medium text-gray-500">{card.label}</p>
                <p className="mt-2 text-3xl font-semibold tracking-tight text-gray-900">
                  {loading ? <span className="text-gray-300">—</span> : card.value}
                </p>
                <p className="mt-1 text-xs text-gray-400">{card.detail}</p>
              </div>
              <span className={`flex h-10 w-10 items-center justify-center rounded-xl ${card.tone}`}>
                <card.icon className="h-5 w-5" aria-hidden="true" />
              </span>
            </div>
          </article>
        ))}
      </section>

      <section>
        <div className="mb-3">
          <h2 className="text-lg font-semibold text-gray-900">Quick access</h2>
          <p className="text-sm text-gray-500">Choose a task to continue.</p>
        </div>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-5">
          {modules.map((module) => (
            <Link key={module.path} to={module.path} className="group rounded-2xl border border-gray-200 bg-white p-4 shadow-sm transition hover:border-supra-red-300 hover:shadow-md">
              <div className="flex items-center justify-between">
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gray-100 text-gray-700 transition group-hover:bg-red-50 group-hover:text-supra-red-600">
                  <module.icon className="h-5 w-5" aria-hidden="true" />
                </span>
                <ArrowUpRight className="h-4 w-4 text-gray-300 group-hover:text-supra-red-600" aria-hidden="true" />
              </div>
              <h3 className="mt-4 text-sm font-semibold text-gray-900">{module.name}</h3>
              <p className="mt-1 text-xs text-gray-500">{module.description}</p>
            </Link>
          ))}
        </div>
      </section>

      <section className={`grid grid-cols-1 gap-5 ${user?.role === 'administrator' ? 'xl:grid-cols-3' : 'xl:grid-cols-2'}`}>
        <article className="overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm">
          <div className="flex items-center justify-between border-b border-gray-100 px-5 py-4">
            <div>
              <h2 className="font-semibold text-gray-900">Recent employees</h2>
              <p className="mt-0.5 text-xs text-gray-500">Latest employee records</p>
            </div>
            <Link to="/employees" className="text-sm font-medium text-supra-red-600 hover:text-supra-red-700">View all</Link>
          </div>
          {loading ? (
            <p className="px-5 py-8 text-center text-sm text-gray-400">Loading employees…</p>
          ) : employees.length === 0 ? (
            <div className="px-5 py-8 text-center">
              <p className="text-sm font-medium text-gray-700">No employee records yet</p>
              <p className="mt-1 text-xs text-gray-500">Add an employee to start using attendance and payroll.</p>
              <Link to="/employees/add" className="mt-4 inline-flex text-sm font-semibold text-supra-red-600 hover:text-supra-red-700">Add first employee <span className="ml-1" aria-hidden="true">→</span></Link>
            </div>
          ) : (
            <ul className="divide-y divide-gray-100">
              {employees.map((employee) => (
                <li key={employee.id} className="flex items-center justify-between gap-3 px-5 py-3">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium text-gray-900">{employee.first_name} {employee.last_name}</p>
                    <p className="mt-0.5 truncate text-xs text-gray-500">{employee.employee_id} · {employee.department_name || 'No department'}</p>
                  </div>
                  <span className="shrink-0 text-xs text-gray-400">{displayDate(employee.date_hired)}</span>
                </li>
              ))}
            </ul>
          )}
        </article>

        <article className="overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm">
          <div className="flex items-center justify-between border-b border-gray-100 px-5 py-4">
            <div>
              <h2 className="font-semibold text-gray-900">Recent payroll</h2>
              <p className="mt-0.5 text-xs text-gray-500">Latest processed payroll records</p>
            </div>
            <Link to="/payroll/history" className="text-sm font-medium text-supra-red-600 hover:text-supra-red-700">View all</Link>
          </div>
          {loading ? (
            <p className="px-5 py-8 text-center text-sm text-gray-400">Loading payroll…</p>
          ) : payroll.length === 0 ? (
            <div className="px-5 py-8 text-center">
              <p className="text-sm font-medium text-gray-700">No payroll records yet</p>
              <p className="mt-1 text-xs text-gray-500">Payroll records will appear here after a payroll run.</p>
              <Link to="/payroll/process" className="mt-4 inline-flex text-sm font-semibold text-supra-red-600 hover:text-supra-red-700">Process payroll <span className="ml-1" aria-hidden="true">→</span></Link>
            </div>
          ) : (
            <ul className="divide-y divide-gray-100">
              {payroll.map((record) => (
                <li key={record.id} className="flex items-center justify-between gap-3 px-5 py-3">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium text-gray-900">{record.first_name} {record.last_name}</p>
                    <p className="mt-0.5 text-xs text-gray-500">{displayDate(record.period_start)} – {displayDate(record.period_end)}</p>
                  </div>
                  <div className="shrink-0 text-right">
                    <p className="text-sm font-semibold text-gray-900">{money.format(Number(record.net_pay) || 0)}</p>
                    <p className="mt-0.5 text-xs text-gray-500">{record.status}</p>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </article>

        {user?.role === 'administrator' && (
          <article className="overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm">
            <div className="flex items-center justify-between border-b border-gray-100 px-5 py-4">
              <div>
                <h2 className="font-semibold text-gray-900">Recent activity</h2>
                <p className="mt-0.5 text-xs text-gray-500">Latest system changes</p>
              </div>
              <Activity className="h-4 w-4 text-gray-400" aria-hidden="true" />
            </div>
            {loading ? (
              <p className="px-5 py-8 text-center text-sm text-gray-400">Loading activity…</p>
            ) : activity.length === 0 ? (
              <p className="px-5 py-8 text-center text-sm text-gray-500">No activity recorded yet.</p>
            ) : (
              <ul className="divide-y divide-gray-100">
                {activity.map((entry) => (
                  <li key={entry.id} className="px-5 py-3">
                    <p className="text-sm font-medium text-gray-800">{entry.description || entry.action.replace(/_/g, ' ')}</p>
                    <p className="mt-1 text-xs text-gray-500">{entry.user_full_name || entry.username || 'System'} · {displayDate(entry.created_at)}</p>
                  </li>
                ))}
              </ul>
            )}
          </article>
        )}
      </section>
    </div>
  );
}
