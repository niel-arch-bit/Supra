const Database = require('better-sqlite3');
const { logActivity } = require('../middleware/activityLogger');

const { DB_PATH } = require('../config/storage');
const db = new Database(DB_PATH);
db.pragma('foreign_keys = ON');

exports.process = (req, res) => {
  try {
    const { employee_id, period_start, period_end } = req.body;

    if (!employee_id || !period_start || !period_end) {
      return res.status(400).json({ error: 'Employee ID, period start, and period end are required.' });
    }

    const employee = db.prepare('SELECT * FROM employees WHERE id = ? AND is_archived = 0').get(employee_id);
    if (!employee) {
      return res.status(404).json({ error: 'Employee not found.' });
    }

    const existing = db.prepare(`
      SELECT * FROM payroll WHERE employee_id = ? AND period_start = ? AND period_end = ?
    `).get(employee_id, period_start, period_end);

    if (existing) {
      return res.status(409).json({ error: 'Payroll already exists for this employee and period.' });
    }

    const attendanceRecords = db.prepare(`
      SELECT * FROM attendance WHERE employee_id = ? AND attendance_date BETWEEN ? AND ?
    `).all(employee_id, period_start, period_end);

    const basicMonthlySalary = parseFloat(employee.basic_monthly_salary) || 0;
    const workingDays = 22;
    const daysPresent = attendanceRecords.filter(r => r.status === 'Present' && r.time_in && r.time_out).length;
    const basicPay = (basicMonthlySalary / workingDays) * daysPresent;

    const hourlyRate = basicMonthlySalary / (workingDays * 8);
    const overtimeRateMultiplier = 1.25;
    let overtimePay = 0;

    attendanceRecords.forEach(record => {
      if (record.time_in && record.time_out && record.total_hours > 8) {
        const otHours = record.total_hours - 8;
        overtimePay += otHours * hourlyRate * overtimeRateMultiplier;
      }
    });

    overtimePay = Math.round(overtimePay * 100) / 100;

    const allowances = 0;
    const bonuses = 0;
    const otherEarnings = 0;
    const totalEarnings = basicPay + overtimePay + allowances + bonuses + otherEarnings;

    const absenceDeduction = (basicMonthlySalary / workingDays) * (attendanceRecords.filter(r => r.status === 'Absent').length || 0);

    const sssRate = 0.045;
    const philhealthRate = 0.05;
    const pagibig = 100;
    const governmentContributions = Math.round((basicMonthlySalary * sssRate + basicMonthlySalary * philhealthRate + pagibig) * 100) / 100;

    let taxWithholding = 0;
    const taxableIncome = totalEarnings;
    if (taxableIncome > 166667) {
      taxWithholding = taxableIncome * 0.30;
    } else if (taxableIncome > 66667) {
      taxWithholding = taxableIncome * 0.25;
    } else if (taxableIncome > 33333) {
      taxWithholding = taxableIncome * 0.20;
    }
    taxWithholding = Math.round(taxWithholding * 100) / 100;

    const otherDeductions = 0;
    const totalDeductions = absenceDeduction + governmentContributions + taxWithholding + otherDeductions;
    const netPay = totalEarnings - totalDeductions;

    const stmt = db.prepare(`
      INSERT INTO payroll (employee_id, period_start, period_end, basic_pay, overtime_pay, allowances,
        bonuses, other_earnings, total_earnings, absence_deduction, government_contributions,
        tax_withholding, other_deductions, total_deductions, net_pay, status, processed_by, processed_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Draft', ?, CURRENT_TIMESTAMP)
    `);
    const result = stmt.run(
      employee_id, period_start, period_end,
      Math.round(basicPay * 100) / 100, overtimePay, allowances, bonuses, otherEarnings,
      Math.round(totalEarnings * 100) / 100,
      Math.round(absenceDeduction * 100) / 100, governmentContributions, taxWithholding,
      otherDeductions, Math.round(totalDeductions * 100) / 100,
      Math.round(netPay * 100) / 100, req.user.id
    );

    logActivity(req.user.id, req.user.username, 'PAYROLL_PROCESSED', 'payroll', result.lastInsertRowid,
      `Processed payroll for ${employee.employee_id} - ${period_start} to ${period_end}`, req);

    res.status(201).json({
      message: 'Payroll processed successfully.',
      payroll_id: result.lastInsertRowid,
      calculation: {
        employee_id: employee.employee_id,
        employee_name: `${employee.first_name} ${employee.last_name}`,
        period_start,
        period_end,
        basic_pay: Math.round(basicPay * 100) / 100,
        overtime_pay: overtimePay,
        allowances,
        bonuses,
        other_earnings: otherEarnings,
        total_earnings: Math.round(totalEarnings * 100) / 100,
        absence_deduction: Math.round(absenceDeduction * 100) / 100,
        government_contributions: governmentContributions,
        tax_withholding: taxWithholding,
        other_deductions: otherDeductions,
        total_deductions: Math.round(totalDeductions * 100) / 100,
        net_pay: Math.round(netPay * 100) / 100,
        status: 'Draft'
      }
    });
  } catch (err) {
    console.error('Process payroll error:', err);
    res.status(500).json({ error: 'Internal server error.' });
  }
};

exports.getAll = (req, res) => {
  try {
    const { employee_id, status, page = 1, limit = 50 } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);

    let query = `
      SELECT p.*, e.employee_id as employee_id_str, e.first_name, e.last_name, d.name as department_name,
        u_processed.full_name as processed_by_name, u_approved.full_name as approved_by_name
      FROM payroll p
      JOIN employees e ON p.employee_id = e.id
      LEFT JOIN departments d ON e.department_id = d.id
      LEFT JOIN users u_processed ON p.processed_by = u_processed.id
      LEFT JOIN users u_approved ON p.approved_by = u_approved.id
      WHERE 1=1
    `;
    const params = [];

    if (employee_id) {
      query += ` AND e.id = ?`;
      params.push(employee_id);
    }
    if (status) {
      query += ` AND p.status = ?`;
      params.push(status);
    }

    query += ` ORDER BY p.created_at DESC LIMIT ? OFFSET ?`;
    params.push(parseInt(limit), offset);

    const records = db.prepare(query).all(params);
    res.json({ records });
  } catch (err) {
    console.error('Get payroll error:', err);
    res.status(500).json({ error: 'Internal server error.' });
  }
};

exports.getById = (req, res) => {
  try {
    const payroll = db.prepare(`
      SELECT p.*, e.employee_id as employee_id_str, e.first_name, e.last_name, e.job_position,
        d.name as department_name,
        u_processed.full_name as processed_by_name,
        u_approved.full_name as approved_by_name
      FROM payroll p
      JOIN employees e ON p.employee_id = e.id
      LEFT JOIN departments d ON e.department_id = d.id
      LEFT JOIN users u_processed ON p.processed_by = u_processed.id
      LEFT JOIN users u_approved ON p.approved_by = u_approved.id
      WHERE p.id = ?
    `).get(req.params.id);

    if (!payroll) {
      return res.status(404).json({ error: 'Payroll record not found.' });
    }

    res.json({ payroll });
  } catch (err) {
    console.error('Get payroll error:', err);
    res.status(500).json({ error: 'Internal server error.' });
  }
};

exports.confirm = (req, res) => {
  try {
    const payroll = db.prepare('SELECT * FROM payroll WHERE id = ?').get(req.params.id);
    if (!payroll) {
      return res.status(404).json({ error: 'Payroll record not found.' });
    }

    if (payroll.status !== 'Draft') {
      return res.status(400).json({ error: 'Only draft payroll can be confirmed.' });
    }

    db.prepare(`
      UPDATE payroll SET status = 'Confirmed', approved_by = ?, approved_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(req.user.id, req.params.id);

    logActivity(req.user.id, req.user.username, 'PAYROLL_CONFIRMED', 'payroll', req.params.id,
      `Confirmed payroll ID ${req.params.id}`, req);

    res.json({ message: 'Payroll confirmed successfully.' });
  } catch (err) {
    console.error('Confirm payroll error:', err);
    res.status(500).json({ error: 'Internal server error.' });
  }
};

exports.pay = (req, res) => {
  try {
    const payroll = db.prepare('SELECT * FROM payroll WHERE id = ?').get(req.params.id);
    if (!payroll) {
      return res.status(404).json({ error: 'Payroll record not found.' });
    }

    if (payroll.status !== 'Confirmed') {
      return res.status(400).json({ error: 'Only confirmed payroll can be marked as paid.' });
    }

    db.prepare(`
      UPDATE payroll SET status = 'Paid', updated_at = CURRENT_TIMESTAMP WHERE id = ?
    `).run(req.params.id);

    logActivity(req.user.id, req.user.username, 'PAYROLL_PAID', 'payroll', req.params.id,
      `Marked payroll ID ${req.params.id} as paid`, req);

    res.json({ message: 'Payroll marked as paid.' });
  } catch (err) {
    console.error('Pay payroll error:', err);
    res.status(500).json({ error: 'Internal server error.' });
  }
};

exports.getSettings = (req, res) => {
  try {
    const settings = db.prepare('SELECT * FROM payroll_settings ORDER BY setting_key').all();
    res.json({ settings });
  } catch (err) {
    console.error('Get payroll settings error:', err);
    res.status(500).json({ error: 'Internal server error.' });
  }
};

exports.updateSetting = (req, res) => {
  try {
    const { setting_key, setting_value } = req.body;
    if (!setting_key || setting_value === undefined) {
      return res.status(400).json({ error: 'Setting key and value are required.' });
    }

    db.prepare(`
      INSERT INTO payroll_settings (setting_key, setting_value, updated_by, updated_at)
      VALUES (?, ?, ?, CURRENT_TIMESTAMP)
      ON CONFLICT(setting_key) DO UPDATE SET
        setting_value = excluded.setting_value,
        updated_by = excluded.updated_by,
        updated_at = CURRENT_TIMESTAMP
    `).run(setting_key, setting_value, req.user.id);

    logActivity(req.user.id, req.user.username, 'PAYROLL_SETTING_UPDATED', 'payroll_setting', null,
      `Updated setting: ${setting_key}`, req);

    res.json({ message: 'Setting updated successfully.' });
  } catch (err) {
    console.error('Update setting error:', err);
    res.status(500).json({ error: 'Internal server error.' });
  }
};
