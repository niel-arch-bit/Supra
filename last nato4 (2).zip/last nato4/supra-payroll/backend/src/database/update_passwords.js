const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '../../.env') });

const { DB_PATH } = require('../config/storage');
const db = new Database(DB_PATH);

const saltRounds = parseInt(process.env.BCRYPT_SALT_ROUNDS || '12', 10);
const users = {
  tan: 'Tan123',
  saraza: 'Saraza123',
  santos: 'Santos123',
  sampayan: 'Sampayan123',
  sison: 'Sison123'
};
const update = db.prepare(
  'UPDATE users SET password_hash = ?, must_change_password = 1, updated_at = CURRENT_TIMESTAMP WHERE username = ?'
);

const updateUsers = db.transaction(() => {
  for (const [username, password] of Object.entries(users)) {
    const info = update.run(bcrypt.hashSync(password, saltRounds), username);
    console.log(`Updated ${username}: ${info.changes} row(s)`);
  }
});

updateUsers();

db.close();
console.log('Done. Demo passwords reset to the credentials listed in the setup guide.');
