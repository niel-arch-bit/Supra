const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const { logActivity } = require('../middleware/activityLogger');

const { DB_PATH } = require('../config/storage');
const db = new Database(DB_PATH);
db.pragma('foreign_keys = ON');

exports.getAll = (req, res) => {
  try {
    const users = db.prepare(`
      SELECT id, full_name, username, email, role, is_active, must_change_password, created_at, updated_at
      FROM users ORDER BY created_at DESC
    `).all();
    res.json({ users });
  } catch (err) {
    console.error('Get users error:', err);
    res.status(500).json({ error: 'Internal server error.' });
  }
};

exports.create = (req, res) => {
  try {
    const { full_name, username, email, password, role } = req.body;

    if (!full_name || !username || !email || !password || !role) {
      return res.status(400).json({ error: 'All fields are required.' });
    }

    if (!['administrator', 'hr_payroll_staff'].includes(role)) {
      return res.status(400).json({ error: 'Invalid role.' });
    }

    const existing = db.prepare('SELECT id FROM users WHERE username = ? OR email = ?').get(username, email);
    if (existing) {
      return res.status(409).json({ error: 'Username or email already exists.' });
    }

    const saltRounds = parseInt(process.env.BCRYPT_SALT_ROUNDS) || 12;
    const passwordHash = bcrypt.hashSync(password, saltRounds);

    const stmt = db.prepare(
      'INSERT INTO users (full_name, username, email, password_hash, role, must_change_password, is_active) VALUES (?, ?, ?, ?, ?, 1, 1)'
    );
    const result = stmt.run(full_name, username, email, passwordHash, role);

    logActivity(req.user.id, req.user.username, 'USER_CREATED', 'user', result.lastInsertRowid,
      `Created user: ${username} (${role})`, req);

    res.status(201).json({ message: 'User created successfully.', id: result.lastInsertRowid });
  } catch (err) {
    console.error('Create user error:', err);
    res.status(500).json({ error: 'Internal server error.' });
  }
};

exports.update = (req, res) => {
  try {
    const { full_name, username, email, role, is_active } = req.body;

    const existing = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id);
    if (!existing) {
      return res.status(404).json({ error: 'User not found.' });
    }

    if (username && username !== existing.username) {
      const dup = db.prepare('SELECT id FROM users WHERE username = ? AND id != ?').get(username, req.params.id);
      if (dup) return res.status(409).json({ error: 'Username already exists.' });
    }
    if (email && email !== existing.email) {
      const dup = db.prepare('SELECT id FROM users WHERE email = ? AND id != ?').get(email, req.params.id);
      if (dup) return res.status(409).json({ error: 'Email already exists.' });
    }

    db.prepare(`
      UPDATE users SET
        full_name = COALESCE(?, full_name),
        username = COALESCE(?, username),
        email = COALESCE(?, email),
        role = COALESCE(?, role),
        is_active = COALESCE(?, is_active),
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(full_name, username, email, role, is_active !== undefined ? is_active : existing.is_active, req.params.id);

    logActivity(req.user.id, req.user.username, 'USER_UPDATED', 'user', req.params.id,
      `Updated user: ${existing.username}`, req);

    res.json({ message: 'User updated successfully.' });
  } catch (err) {
    console.error('Update user error:', err);
    res.status(500).json({ error: 'Internal server error.' });
  }
};

exports.resetPassword = (req, res) => {
  try {
    const { new_password } = req.body;
    if (!new_password || new_password.length < 6) {
      return res.status(400).json({ error: 'New password must be at least 6 characters.' });
    }

    const existing = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id);
    if (!existing) {
      return res.status(404).json({ error: 'User not found.' });
    }

    const saltRounds = parseInt(process.env.BCRYPT_SALT_ROUNDS) || 12;
    const passwordHash = bcrypt.hashSync(new_password, saltRounds);

    db.prepare('UPDATE users SET password_hash = ?, must_change_password = 1, updated_at = CURRENT_TIMESTAMP WHERE id = ?')
      .run(passwordHash, req.params.id);

    logActivity(req.user.id, req.user.username, 'USER_PASSWORD_RESET', 'user', req.params.id,
      `Reset password for user: ${existing.username}`, req);

    res.json({ message: 'Password reset successfully.' });
  } catch (err) {
    console.error('Reset password error:', err);
    res.status(500).json({ error: 'Internal server error.' });
  }
};

exports.deactivate = (req, res) => {
  try {
    const existing = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id);
    if (!existing) {
      return res.status(404).json({ error: 'User not found.' });
    }

    if (existing.id === req.user.id) {
      return res.status(400).json({ error: 'Cannot deactivate your own account.' });
    }

    db.prepare('UPDATE users SET is_active = 0, updated_at = CURRENT_TIMESTAMP WHERE id = ?')
      .run(req.params.id);

    logActivity(req.user.id, req.user.username, 'USER_DEACTIVATED', 'user', req.params.id,
      `Deactivated user: ${existing.username}`, req);

    res.json({ message: 'User deactivated successfully.' });
  } catch (err) {
    console.error('Deactivate user error:', err);
    res.status(500).json({ error: 'Internal server error.' });
  }
};
