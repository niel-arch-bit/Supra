const express = require('express');
const router = express.Router();
const activityLogController = require('../controllers/activityLogController');
const { authenticateToken, requireActiveUser, authorizeRoles } = require('../middleware/auth');

router.get('/', authenticateToken, requireActiveUser, authorizeRoles('administrator'), activityLogController.getAll);

module.exports = router;