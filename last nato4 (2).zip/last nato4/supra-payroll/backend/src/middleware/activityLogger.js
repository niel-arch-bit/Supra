const { db } = require('./auth');

function logActivity(userId, username, action, entityType, entityId, description, req) {
  try {
    const ipAddress = req.ip || (req.connection && req.connection.remoteAddress) || '';
    const userAgent = req.get('User-Agent') || '';
    const stmt = db.prepare(
      'INSERT INTO activity_logs (user_id, username, action, entity_type, entity_id, description, ip_address, user_agent) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
    );
    stmt.run(userId || null, username || null, action, entityType || null, entityId || null, description || null, ipAddress, userAgent);
  } catch (err) {
    console.error('Activity log error:', err.message);
  }
}

function activityLogger(action, entityType = null) {
  return (req, res, next) => {
    const originalSend = res.send;
    res.send = function (body) {
      const user = req.user || null;
      if (user && res.statusCode < 400) {
        logActivity(
          user.id,
          user.username,
          action,
          entityType,
          null,
          `${action} performed on ${entityType || 'unknown'}`,
          req
        );
      }
      return originalSend.call(this, body);
    };
    next();
  };
}

module.exports = { logActivity, activityLogger };