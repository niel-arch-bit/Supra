import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { toast } from 'react-hot-toast';
import api from '../services/api';
import { Search, Filter, Plus, Trash2, Edit3, Eye } from 'lucide-react';
import type { Employee } from '../types';

export default function EmployeeList() {
  const navigate = useNavigate();
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [departments, setDepartments] = useState<any[]>([]);
  const [filters, setFilters] = useState({ search: '', department: '', status: '', archived: 'false' });
  const [loading, setLoading] = useState(true);
  const [pagination, setPagination] = useState({ page: 1, limit: 50, total: 0, pages: 0 });

  useEffect(() => {
    loadDepartments();
    loadEmployees();
  }, []);

  const loadDepartments = async () => {
    try {
      const res = await api.get('/employees/departments');
      setDepartments(res.data.departments);
    } catch (err) {
      toast.error('Failed to load departments');
    }
  };

  const loadEmployees = async () => {
    setLoading(true);
    try {
      const res = await api.get('/employees/', {
        params: { ...filters, page: pagination.page, limit: pagination.limit }
      });
      setEmployees(res.data.employees);
      setPagination(res.data.pagination);
    } catch (err) {
      toast.error('Failed to load employees');
    } finally {
      setLoading(false);
    }
  };

  const handleArchive = async (id: number) => {
    if (!window.confirm('Archive this employee? This action cannot be easily undone.')) return;
    try {
      await api.patch(`/employees/${id}/archive`);
      toast.success('Employee archived');
      loadEmployees();
    } catch (err) {
      toast.error('Failed to archive employee');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Manage Employees</h1>
          <p className="text-gray-500">View and manage employee records</p>
        </div>
        <Link to="/employees/add" className="supra-btn-primary flex items-center gap-2">
          <Plus className="w-4 h-4" />
          Add Employee
        </Link>
      </div>

      <div className="supra-card p-6">
        <div className="flex flex-wrap items-center gap-4 mb-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              value={filters.search}
              onChange={(e) => setFilters({ ...filters, search: e.target.value })}
              className="supra-input pl-10"
              placeholder="Search by name or Employee ID"
            />
          </div>
          <select
            value={filters.department}
            onChange={(e) => setFilters({ ...filters, department: e.target.value })}
            className="supra-input"
          >
            <option value="">All Departments</option>
            {departments.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
          </select>
          <select
            value={filters.status}
            onChange={(e) => setFilters({ ...filters, status: e.target.value })}
            className="supra-input"
          >
            <option value="">All Status</option>
            <option value="Regular">Regular</option>
            <option value="Probationary">Probationary</option>
            <option value="Contractual">Contractual</option>
            <option value="Casual">Casual</option>
          </select>
          <button onClick={() => loadEmployees()} className="supra-btn-secondary px-4">
            <Filter className="w-4 h-4 mr-2" />
            Filter
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="supra-table">
            <thead>
              <tr>
                <th>Employee ID</th>
                <th>Full Name</th>
                <th>Department</th>
                <th>Position</th>
                <th>Date Hired</th>
                <th>Status</th>
                <th className="text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={7} className="text-center py-8 text-gray-500">Loading...</td></tr>
              ) : employees.length === 0 ? (
                <tr><td colSpan={7} className="text-center py-8 text-gray-500">No employees found.</td></tr>
              ) : (
                employees.map((emp) => (
                  <tr key={emp.id} className="hover:bg-gray-50/50 transition-colors">
                    <td className="font-medium text-gray-900">{emp.employee_id}</td>
                    <td className="text-gray-700">{emp.first_name} {emp.last_name}</td>
                    <td className="text-gray-700">{emp.department_name || '-'}</td>
                    <td className="text-gray-700">{emp.job_position || '-'}</td>
                    <td className="text-gray-700 text-sm">{emp.date_hired}</td>
                    <td>
                      <span className={`supra-badge ${emp.employment_status === 'Regular' ? 'badge-present' : 'badge-pending'}`}>
                        {emp.employment_status}
                      </span>
                    </td>
                    <td className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button onClick={() => navigate(`/employees/${emp.id}`)} className="text-gray-600 hover:text-supra-red-600" title="View">
                          <Eye className="w-4 h-4" />
                        </button>
                        <button onClick={() => navigate(`/employees/${emp.id}/edit`)} className="text-gray-600 hover:text-supra-red-600" title="Edit">
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button onClick={() => handleArchive(emp.id)} className="text-red-600 hover:text-red-800" title="Archive">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {pagination.pages > 1 && (
          <div className="mt-4 flex items-center justify-between">
            <p className="text-sm text-gray-500">Page {pagination.page} of {pagination.pages}</p>
            <div className="flex gap-1">
              <button
                disabled={pagination.page === 1}
                onClick={() => setPagination({ ...pagination, page: pagination.page - 1 })}
                className="px-3 py-1 rounded-lg text-sm border border-gray-200 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Prev
              </button>
              <button
                disabled={pagination.page >= pagination.pages}
                onClick={() => setPagination({ ...pagination, page: pagination.page + 1 })}
                className="px-3 py-1 rounded-lg text-sm border border-gray-200 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Next
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
