const Database = require('better-sqlite3');
const { DB_PATH } = require('../config/storage');
const db = new Database(DB_PATH);
try {
  const users = db.prepare('SELECT id, username, password_hash, is_active FROM users').all();
  console.log('USERS:', JSON.stringify(users, null, 2));
} catch (e) {
  console.log('ERROR:', e.message);
}
db.close();
