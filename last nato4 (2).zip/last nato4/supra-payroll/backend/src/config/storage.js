const fs = require('fs');
const path = require('path');

const backendRoot = path.resolve(__dirname, '../..');
const configuredStorageRoot = process.env.SUPRA_DATA_DIR?.trim();

function resolveConfiguredPath(value) {
  return path.isAbsolute(value) ? value : path.resolve(backendRoot, value);
}

const storageRoot = configuredStorageRoot
  ? resolveConfiguredPath(configuredStorageRoot)
  : backendRoot;

const DB_PATH = configuredStorageRoot
  ? path.join(storageRoot, 'database', 'supra.db')
  : resolveConfiguredPath(process.env.DB_PATH?.trim() || './database/supra.db');

const UPLOAD_PATH = configuredStorageRoot
  ? path.join(storageRoot, 'uploads')
  : resolveConfiguredPath(process.env.UPLOAD_PATH?.trim() || './uploads');

fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
fs.mkdirSync(UPLOAD_PATH, { recursive: true });

module.exports = { DB_PATH, UPLOAD_PATH, storageRoot };
