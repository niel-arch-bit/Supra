const express = require('express');
const router = express.Router();
const employeeController = require('../controllers/employeeController');
const { authenticateToken, requireActiveUser, authorizeRoles } = require('../middleware/auth');

router.get('/', authenticateToken, requireActiveUser, employeeController.getAll);
// Keep fixed paths above /:id so they are not treated as employee IDs.
router.get('/departments', authenticateToken, requireActiveUser, employeeController.getDepartments);
router.get('/dashboard-stats', authenticateToken, requireActiveUser, employeeController.getDashboardStats);
router.get('/:id', authenticateToken, requireActiveUser, employeeController.getById);
router.post('/', authenticateToken, requireActiveUser, authorizeRoles('administrator', 'hr_payroll_staff'), employeeController.create);
router.put('/:id', authenticateToken, requireActiveUser, authorizeRoles('administrator', 'hr_payroll_staff'), employeeController.update);
router.patch('/:id/archive', authenticateToken, requireActiveUser, authorizeRoles('administrator', 'hr_payroll_staff'), employeeController.archive);

module.exports = router;
