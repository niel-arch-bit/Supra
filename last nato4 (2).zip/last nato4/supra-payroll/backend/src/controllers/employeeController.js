const Database = require('better-sqlite3');
const { logActivity } = require('../middleware/activityLogger');

const { DB_PATH } = require('../config/storage');
const db = new Database(DB_PATH);
db.pragma('foreign_keys = ON');

exports.getAll = (req, res) => {
  try {
    const { search, department, status, page = 1, limit = 50, archived = 'false' } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);
    const showArchived = archived === 'true';

    let query = `
      SELECT e.*, d.name as department_name
      FROM employees e
      LEFT JOIN departments d ON e.department_id = d.id
      WHERE e.is_archived = ${showArchived ? 1 : 0}
    `;
    const params = [];

    if (search) {
      query += ` AND (e.first_name LIKE ? OR e.last_name LIKE ? OR e.employee_id LIKE ? OR e.middle_name LIKE ?)`;
      const searchTerm = `%${search}%`;
      params.push(searchTerm, searchTerm, searchTerm, searchTerm);
    }

    if (department) {
      query += ` AND e.department_id = ?`;
      params.push(department);
    }

    if (status) {
      query += ` AND e.employment_status = ?`;
      params.push(status);
    }

    query += ` ORDER BY e.created_at DESC LIMIT ? OFFSET ?`;
    params.push(parseInt(limit), offset);

    const employees = db.prepare(query).all(params);

    let countQuery = `SELECT COUNT(*) as total FROM employees e WHERE e.is_archived = ${showArchived ? 1 : 0}`;
    const countParams = [];
    if (search) {
      countQuery += ` AND (e.first_name LIKE ? OR e.last_name LIKE ? OR e.employee_id LIKE ? OR e.middle_name LIKE ?)`;
      const searchTerm = `%${search}%`;
      countParams.push(searchTerm, searchTerm, searchTerm, searchTerm);
    }
    if (department) {
      countQuery += ` AND e.department_id = ?`;
      countParams.push(department);
    }
    if (status) {
      countQuery += ` AND e.employment_status = ?`;
      countParams.push(status);
    }

    const totalRow = db.prepare(countQuery).get(countParams);
    const total = totalRow.total;

    res.json({
      employees,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / parseInt(limit))
      }
    });
  } catch (err) {
    console.error('Get employees error:', err);
    res.status(500).json({ error: 'Internal server error.' });
  }
};

exports.getById = (req, res) => {
  try {
    const employee = db.prepare(`
      SELECT e.*, d.name as department_name
      FROM employees e
      LEFT JOIN departments d ON e.department_id = d.id
      WHERE e.id = ?
    `).get(req.params.id);

    if (!employee) {
      return res.status(404).json({ error: 'Employee not found.' });
    }

    res.json({ employee });
  } catch (err) {
    console.error('Get employee error:', err);
    res.status(500).json({ error: 'Internal server error.' });
  }
};

exports.getDepartments = (req, res) => {
  try {
    const departments = db.prepare('SELECT * FROM departments ORDER BY name').all();
    res.json({ departments });
  } catch (err) {
    console.error('Get departments error:', err);
    res.status(500).json({ error: 'Internal server error.' });
  }
};

exports.getDashboardStats = (req, res) => {
  try {
    const totalEmployees = db.prepare("SELECT COUNT(*) as count FROM employees WHERE is_archived = 0").get().count;
    const today = new Date().toISOString().split('T')[0];
    const presentToday = db.prepare("SELECT COUNT(*) as count FROM attendance WHERE attendance_date = ? AND status = 'Present'").get(today).count;
    const absentToday = db.prepare("SELECT COUNT(*) as count FROM attendance WHERE attendance_date = ? AND status = 'Absent'").get(today).count;
    const pendingPayroll = db.prepare("SELECT COUNT(*) as count FROM payroll WHERE status = 'Draft'").get().count;
    const totalPayrollCurrentPeriod = db.prepare(`
      SELECT COALESCE(SUM(net_pay), 0) as total
      FROM payroll
      WHERE period_start <= date('now', 'localtime')
        AND period_end >= date('now', 'localtime')
        AND status != 'Cancelled'
    `).get().total;

    res.json({
      total_employees: totalEmployees,
      present_today: presentToday,
      absent_today: absentToday,
      pending_payroll: pendingPayroll,
      total_payroll_current_period: totalPayrollCurrentPeriod
    });
  } catch (err) {
    console.error('Dashboard stats error:', err);
    res.status(500).json({ error: 'Internal server error.' });
  }
};

exports.create = (req, res) => {
  try {
    const {
      employee_id, first_name, middle_name, last_name, gender,
      date_of_birth, contact_number, email, home_address,
      department_id, job_position, employment_status, date_hired, basic_monthly_salary
    } = req.body;

    if (!employee_id || !first_name || !last_name || !date_hired) {
      return res.status(400).json({ error: 'Employee ID, first name, last name, and date hired are required.' });
    }

    const existing = db.prepare('SELECT id FROM employees WHERE employee_id = ?').get(employee_id);
    if (existing) {
      return res.status(409).json({ error: 'Employee ID already exists.' });
    }

    const stmt = db.prepare(`
      INSERT INTO employees (employee_id, first_name, middle_name, last_name, gender, date_of_birth,
        contact_number, email, home_address, department_id, job_position, employment_status, date_hired, basic_monthly_salary)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    const result = stmt.run(
      employee_id, first_name, middle_name || null, last_name, gender || null,
      date_of_birth || null, contact_number || null, email || null, home_address || null,
      department_id || null, job_position || null, employment_status || 'Regular',
      date_hired, parseFloat(basic_monthly_salary) || 0
    );

    logActivity(req.user.id, req.user.username, 'EMPLOYEE_CREATED', 'employee', result.lastInsertRowid,
      `Created employee: ${employee_id} - ${first_name} ${last_name}`, req);

    res.status(201).json({ message: 'Employee created successfully.', id: result.lastInsertRowid });
  } catch (err) {
    console.error('Create employee error:', err);
    res.status(500).json({ error: 'Internal server error.' });
  }
};

exports.update = (req, res) => {
  try {
    const {
      employee_id, first_name, middle_name, last_name, gender,
      date_of_birth, contact_number, email, home_address,
      department_id, job_position, employment_status, date_hired, basic_monthly_salary, is_archived
    } = req.body;

    const existing = db.prepare('SELECT * FROM employees WHERE id = ?').get(req.params.id);
    if (!existing) {
      return res.status(404).json({ error: 'Employee not found.' });
    }

    if (employee_id && employee_id !== existing.employee_id) {
      const dup = db.prepare('SELECT id FROM employees WHERE employee_id = ? AND id != ?').get(employee_id, req.params.id);
      if (dup) {
        return res.status(409).json({ error: 'Employee ID already exists.' });
      }
    }

    const stmt = db.prepare(`
      UPDATE employees SET
        employee_id = COALESCE(?, employee_id),
        first_name = COALESCE(?, first_name),
        middle_name = COALESCE(?, middle_name),
        last_name = COALESCE(?, last_name),
        gender = COALESCE(?, gender),
        date_of_birth = COALESCE(?, date_of_birth),
        contact_number = COALESCE(?, contact_number),
        email = COALESCE(?, email),
        home_address = COALESCE(?, home_address),
        department_id = COALESCE(?, department_id),
        job_position = COALESCE(?, job_position),
        employment_status = COALESCE(?, employment_status),
        date_hired = COALESCE(?, date_hired),
        basic_monthly_salary = COALESCE(?, basic_monthly_salary),
        is_archived = COALESCE(?, is_archived),
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `);
    stmt.run(
      employee_id, first_name, middle_name, last_name, gender,
      date_of_birth, contact_number, email, home_address,
      department_id, job_position, employment_status, date_hired, basic_monthly_salary,
      is_archived !== undefined ? is_archived : existing.is_archived,
      req.params.id
    );

    logActivity(req.user.id, req.user.username, 'EMPLOYEE_UPDATED', 'employee', req.params.id,
      `Updated employee: ${existing.employee_id}`, req);

    res.json({ message: 'Employee updated successfully.' });
  } catch (err) {
    console.error('Update employee error:', err);
    res.status(500).json({ error: 'Internal server error.' });
  }
};

exports.archive = (req, res) => {
  try {
    const existing = db.prepare('SELECT * FROM employees WHERE id = ?').get(req.params.id);
    if (!existing) {
      return res.status(404).json({ error: 'Employee not found.' });
    }

    db.prepare('UPDATE employees SET is_archived = 1, updated_at = CURRENT_TIMESTAMP WHERE id = ?')
      .run(req.params.id);

    logActivity(req.user.id, req.user.username, 'EMPLOYEE_ARCHIVED', 'employee', req.params.id,
      `Archived employee: ${existing.employee_id} - ${existing.first_name} ${existing.last_name}`, req);

    res.json({ message: 'Employee archived successfully.' });
  } catch (err) {
    console.error('Archive employee error:', err);
    res.status(500).json({ error: 'Internal server error.' });
  }
};
