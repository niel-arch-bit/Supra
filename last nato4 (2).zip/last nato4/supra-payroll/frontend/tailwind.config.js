/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        supra: {
          black: {
            DEFAULT: '#0a0a0a',
            900: '#0a0a0a',
          },
          charcoal: '#1a1a1a',
          red: {
            DEFAULT: '#dc2626',
            50: '#fef2f2',
            100: '#fee2e2',
            400: '#f87171',
            500: '#ef4444',
            600: '#dc2626',
            700: '#b91c1c',
            800: '#991b1b',
            900: '#7f1d1d',
          },
          'red-dark': '#b91c1c',
          'red-light': '#fca5a5',
          white: '#ffffff',
          gray: '#f3f4f6',
          'gray-dark': '#6b7280',
        }
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        display: ['Segoe UI', 'system-ui', 'sans-serif'],
      },
      borderRadius: {
        'xl': '0.75rem',
        '2xl': '1rem',
      },
      boxShadow: {
        'supra': '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)',
        'supra-red': '0 0 15px rgba(220, 38, 38, 0.3)',
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
      }
    },
  },
  plugins: [],
}
