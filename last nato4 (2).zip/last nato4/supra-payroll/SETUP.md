# SUPRA Employee Management and Payroll System - Setup Guide

Step-by-step installation and deployment instructions.

---

## Prerequisites Check

Before installing, verify you have the following:

```bash
node --version   # Should be v18 or higher
npm --version    # Should come with Node.js
```

If Node.js is not installed, download it from: https://nodejs.org/

---

## Step 1: Install Backend Dependencies

```bash
cd "c:/Users/1/Documents/last nato4/supra-payroll/backend"
npm install
```

This installs: express, cors, helmet, bcryptjs, jsonwebtoken, dotenv, multer, sqlite3, better-sqlite3, uuid, express-validator, nodemon

---

## Step 2: Install Frontend Dependencies

```bash
cd "c:/Users/1/Documents/last nato4/supra-payroll/frontend"
npm install
```

This installs: react, react-dom, react-router-dom, axios, lucide-react, tailwindcss, postcss, autoprefixer, typescript, vite, jspdf, html2canvas, react-hot-toast, clsx, tailwind-merge, date-fns

---

## Step 3: Configure Environment

The backend `.env` file has been created with default values:

```
NODE_ENV=development
PORT=5000
JWT_SECRET=supra_secret_key_change_in_production_2026
JWT_EXPIRES_IN=24h
BCRYPT_SALT_ROUNDS=12
FRONTEND_URL=http://localhost:3000
DB_PATH=./database/supra.db
UPLOAD_PATH=./uploads
MAX_FILE_SIZE=10485760
```

**Important:** Change `JWT_SECRET` to a strong random string in production.

---

## Step 4: Initialize Database

```bash
cd "c:/Users/1/Documents/last nato4/supra-payroll/backend"
npm run setup
```

This will:
- Create the `database/` directory
- Create `supra.db` SQLite database
- Run the schema (10 tables)
- Insert default departments
- Insert payroll settings (Philippine payroll rules)
- Seed 5 demo user accounts
- In development, seed fictional `DEMO-` employees, payslips, and private sample employee files

Expected output:
```
🔧 Setting up SUPRA database...
✓ Database schema created
✓ Default departments inserted
✓ Payroll settings inserted
✓ Demo user created: tan (administrator)
✓ Demo user created: saraza (hr_payroll_staff)
✓ Demo user created: santos (hr_payroll_staff)
✓ Demo user created: sampayan (hr_payroll_staff)
✓ Demo user created: sison (hr_payroll_staff)

✅ Database setup complete!
📍 Database file: C:\...\supra-payroll\backend\database\supra.db
👥 Demo accounts:
   tan / Tan123 (Administrator)
   saraza / Saraza123 (HR/Payroll Staff)
   santos / Santos123 (HR/Payroll Staff)
   sampayan / Sampayan123 (HR/Payroll Staff)
   sison / Sison123 (HR/Payroll Staff)
Users can change their password from the Profile page.
```

---

## Step 5: Start the Backend Server

```bash
cd "c:/Users/1/Documents/last nato4/supra-payroll/backend"
npm run dev
```

Expected output:
```
🚀 SUPRA Employee Management and Payroll System
📡 Server running on port 5000
🌐 Environment: development
📊 Database: C:\...\supra-payroll\backend\database\supra.db
🔗 API: http://localhost:5000/api
```

The API will be available at `http://localhost:5000/api`

---

## Step 6: Start the Frontend Server

```bash
cd "c:/Users/1/Documents/last nato4/supra-payroll/frontend"
npm run dev
```

Expected output:
```
  VITE v5.x  ready in xxx ms

  ➜  Local:   http://localhost:3000/
  ➜  Network: use --host to expose
```

The frontend proxies API requests to `http://localhost:5000` automatically.

---

## Step 7: Access the Application

Open your browser and navigate to:

**http://localhost:3000**

You will see the SUPRA login page.

---

## Step 8: First Login

Use one of the demo accounts:

| Username | Password | Role |
|----------|----------|------|
| tan | Tan123 | Administrator |
| saraza | Saraza123 | HR/Payroll Staff |

You will be prompted to change your password on first login.

You can change your password later from the Profile page.

## Netlify deployment

The repository includes a Render Blueprint for the API and Netlify proxy rules for `/api`. This keeps the frontend on Netlify and connects it to a persistent Express backend without requiring a Netlify API URL setting.

1. Push this repository to GitHub.
2. In Render, choose **New > Blueprint**, select this repository, and deploy the root `render.yaml` file. It creates the backend service, generates a JWT secret, initializes the database and fictional demo records on first start, and adds a persistent disk for the SQLite database and uploaded files.
3. Wait for the API health check at `https://supra-payroll-api-cozy-raindrop-db4025.onrender.com/health` to return `{"status":"ok"}`.
4. Push the latest repository changes and let Netlify redeploy. The `/api/*` proxy is configured in `netlify.toml`, so the frontend continues to call `/api`.

The Render Blueprint uses a paid service plan because this payroll app must preserve its SQLite database and uploaded employee files across restarts. Render's free service filesystem is temporary. If Render reports that the service name is already taken, update the API hostname in both root and `supra-payroll/netlify.toml` before deploying.

---

## Troubleshooting

### Port already in use
If port 5000 or 3000 is already in use, change the PORT in `.env` or `vite.config.ts`.

### Database locked
SQLite may lock if multiple processes access it. Close all instances and restart.

### CORS errors
Ensure `FRONTEND_URL` in `.env` matches your frontend URL exactly.

### Module not found errors
Run `npm install` again in the affected directory.

### File upload fails
Check that the `uploads/` directory exists and is writable.

---

## Production Deployment

1. Set `NODE_ENV=production` in `.env`
2. Change `JWT_SECRET` to a strong random value
3. Build the frontend: `npm run build` (creates `dist/` folder)
4. Serve the backend on a production server (e.g., PM2, systemd)
5. Configure a reverse proxy (Nginx/Apache) for SSL and port 80/443
6. Set up regular database backups of `supra.db`
