import React, { Suspense, lazy, useState } from 'react';
import { BrowserRouter, Navigate, Outlet, Route, Routes, useLocation } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { Toast } from './components/Toast';

const Login = lazy(() => import('./pages/Login'));
const Register = lazy(() => import('./pages/Register'));
const Dashboard = lazy(() => import('./pages/Dashboard'));
const Profile = lazy(() => import('./pages/Profile'));
const EmployeeList = lazy(() => import('./pages/EmployeeList'));
const AddEmployee = lazy(() => import('./pages/AddEmployee'));
const AttendanceRecord = lazy(() => import('./pages/AttendanceRecord'));
const AttendanceRecords = lazy(() => import('./pages/AttendanceRecords'));
const AttendanceReports = lazy(() => import('./pages/AttendanceReports'));
const PayrollProcess = lazy(() => import('./pages/PayrollProcess'));
const PayrollHistory = lazy(() => import('./pages/PayrollHistory'));
const PayslipView = lazy(() => import('./pages/PayslipView'));
const PayslipPrint = lazy(() => import('./pages/PayslipPrint'));
const Employee201 = lazy(() => import('./pages/Employee201'));
const Employee201Upload = lazy(() => import('./pages/Employee201Upload'));
const UserManagement = lazy(() => import('./pages/UserManagement'));
const ActivityLogs = lazy(() => import('./pages/ActivityLogs'));
const Settings = lazy(() => import('./pages/Settings'));

function PageLoading() {
  return (
    <div className="flex min-h-[40vh] items-center justify-center text-sm text-gray-500" role="status">
      Loading SUPRA…
    </div>
  );
}

function RequireAuth() {
  const { isAuthenticated, isLoading } = useAuth();
  const location = useLocation();

  if (isLoading) return <PageLoading />;
  if (!isAuthenticated) return <Navigate to="/login" replace state={{ from: location }} />;

  return <Outlet />;
}

function GuestOnly({ children }: { children: React.ReactNode }) {
  const { isAuthenticated, isLoading } = useAuth();
  if (isLoading) return <PageLoading />;
  if (isAuthenticated) return <Navigate to="/dashboard" replace />;
  return <>{children}</>;
}

function RequireAdministrator() {
  const { hasRole } = useAuth();
  return hasRole('administrator') ? <Outlet /> : <Navigate to="/dashboard" replace />;
}

function AppLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50">
      {sidebarOpen && (
        <button
          type="button"
          aria-label="Close navigation menu"
          className="fixed inset-0 z-40 bg-black/40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
      <Sidebar mobileOpen={sidebarOpen} onNavigate={() => setSidebarOpen(false)} />
      <Navbar onMenuClick={() => setSidebarOpen(true)} />
      <main className="min-h-screen px-4 pb-8 pt-20 sm:px-6 lg:ml-64 lg:px-8">
        <Suspense fallback={<PageLoading />}>
          <Outlet />
        </Suspense>
      </main>
    </div>
  );
}

function AppRoutes() {
  return (
    <>
      <Toast />
      <Suspense fallback={<PageLoading />}>
        <Routes>
          <Route path="/login" element={<GuestOnly><Login /></GuestOnly>} />
          <Route path="/register" element={<GuestOnly><Register /></GuestOnly>} />

          <Route element={<RequireAuth />}>
            <Route path="/change-password" element={<Navigate to="/profile" replace />} />
            <Route element={<AppLayout />}>
              <Route index element={<Navigate to="/dashboard" replace />} />
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/profile" element={<Profile />} />

              <Route path="/employees" element={<EmployeeList />} />
              <Route path="/employees/add" element={<AddEmployee />} />
              <Route path="/attendance" element={<Navigate to="/attendance/record" replace />} />
              <Route path="/attendance/record" element={<AttendanceRecord />} />
              <Route path="/attendance/records" element={<AttendanceRecords />} />
              <Route path="/attendance/reports" element={<AttendanceReports />} />
              <Route path="/payroll" element={<Navigate to="/payroll/process" replace />} />
              <Route path="/payroll/process" element={<PayrollProcess />} />
              <Route path="/payroll/history" element={<PayrollHistory />} />
              <Route path="/payslip" element={<Navigate to="/payslip/view" replace />} />
              <Route path="/payslip/view" element={<PayslipView />} />
              <Route path="/payslip/print" element={<Navigate to="/payslip/view" replace />} />
              <Route path="/payslip/print/:id" element={<PayslipPrint />} />
              <Route path="/employee201" element={<Employee201 />} />
              <Route path="/employee201/upload" element={<Employee201Upload />} />
              <Route path="/settings" element={<Settings />} />

              <Route element={<RequireAdministrator />}>
                <Route path="/users" element={<UserManagement />} />
                <Route path="/activity-logs" element={<ActivityLogs />} />
              </Route>

              <Route path="*" element={<Navigate to="/dashboard" replace />} />
            </Route>
          </Route>
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Suspense>
    </>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppRoutes />
      </AuthProvider>
    </BrowserRouter>
  );
}
