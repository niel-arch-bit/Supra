import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { toast } from 'react-hot-toast';
import { Lock, ArrowLeft, Loader2, CheckCircle } from 'lucide-react';
import { SupraLogo } from '../components/SupraLogo';

export default function ChangePassword() {
  const [formData, setFormData] = useState({ current_password: '', new_password: '' });
  const [loading, setLoading] = useState(false);
  const [changed, setChanged] = useState(false);
  const { changePassword } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await changePassword(formData.current_password, formData.new_password);
      setChanged(true);
      toast.success('Password changed successfully!');
    } catch (err: any) {
      toast.error(err.response?.data?.error || 'Password change failed.');
    } finally {
      setLoading(false);
    }
  };

  if (changed) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-supra-black">
        <div className="text-center">
          <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="w-8 h-8 text-white" />
          </div>
          <SupraLogo size="md" className="text-white mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-white mb-2">Password Updated</h1>
          <p className="text-gray-400 mb-8">Your password has been changed successfully.</p>
          <button
            onClick={() => navigate('/dashboard')}
            className="supra-btn-primary px-8"
          >
            Go to Dashboard
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex items-center justify-center min-h-screen bg-supra-black">
      <div className="w-full max-w-md px-6">
        <div className="text-center mb-8">
          <SupraLogo size="md" className="text-white mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-white">Change Password</h1>
          <p className="text-supra-red-400 text-sm mt-1">Required on first login</p>
        </div>

        <div className="bg-white rounded-3xl shadow-2xl p-8 border border-gray-100">
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Current Password</label>
              <Lock className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
              <input
                type="password"
                value={formData.current_password}
                onChange={(e) => setFormData({ ...formData, current_password: e.target.value })}
                className="supra-input pl-10"
                placeholder="Enter current password"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">New Password</label>
              <input
                type="password"
                value={formData.new_password}
                onChange={(e) => setFormData({ ...formData, new_password: e.target.value })}
                className="supra-input"
                placeholder="Enter new password (min 6 chars)"
                required
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="supra-btn-primary w-full disabled:opacity-60 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {loading ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <>
                  Update Password <ArrowLeft className="w-4 h-4" />
                </>
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}