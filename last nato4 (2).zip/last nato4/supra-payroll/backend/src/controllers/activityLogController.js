const Database = require('better-sqlite3');
const { DB_PATH } = require('../config/storage');
const db = new Database(DB_PATH);
db.pragma('foreign_keys = ON');

exports.getAll = (req, res) => {
  try {
    const { page = 1, limit = 100, action, user_id } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);

    let query = `
      SELECT al.*, u.full_name as user_full_name
      FROM activity_logs al
      LEFT JOIN users u ON al.user_id = u.id
      WHERE 1=1
    `;
    const params = [];

    if (action) {
      query += ` AND al.action = ?`;
      params.push(action);
    }
    if (user_id) {
      query += ` AND al.user_id = ?`;
      params.push(user_id);
    }

    query += ` ORDER BY al.created_at DESC LIMIT ? OFFSET ?`;
    params.push(parseInt(limit), offset);

    const logs = db.prepare(query).all(params);
    res.json({ logs });
  } catch (err) {
    console.error('Get activity logs error:', err);
    res.status(500).json({ error: 'Internal server error.' });
  }
};
