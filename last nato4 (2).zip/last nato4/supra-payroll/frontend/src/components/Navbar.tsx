import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { ChevronDown, LogOut, Menu, UserRound } from 'lucide-react';
import { SupraLogo } from './SupraLogo';

export function Navbar({ onMenuClick }: { onMenuClick: () => void }) {
  const { user, logout } = useAuth();
  const [profileMenuOpen, setProfileMenuOpen] = useState(false);

  return (
    <header className="fixed top-0 left-0 right-0 z-40 bg-white/80 backdrop-blur-md border-b border-gray-100 lg:pl-64">
      <div className="flex items-center justify-between px-6 py-3">
        <div className="flex items-center gap-4">
          <button type="button" onClick={onMenuClick} className="rounded-lg p-2 text-gray-600 hover:bg-gray-100 hover:text-gray-900 lg:hidden" aria-label="Open navigation menu">
            <Menu className="w-6 h-6" />
          </button>
          <Link to="/dashboard" className="flex items-center gap-3">
            <SupraLogo size="md" className="text-supra-black-900" />
          </Link>
        </div>

        <div className="relative">
          <button
            type="button"
            onClick={() => setProfileMenuOpen((open) => !open)}
            aria-expanded={profileMenuOpen}
            aria-haspopup="menu"
            className="flex items-center gap-3 rounded-xl px-2 py-1.5 text-left hover:bg-gray-50"
          >
            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-supra-black text-sm font-bold text-white">
              {user?.full_name?.charAt(0) || user?.username?.charAt(0)}
            </span>
            <span className="hidden sm:block">
              <span className="block text-sm font-medium text-gray-900">{user?.full_name}</span>
              <span className="block text-xs capitalize text-gray-500">{user?.role.replace(/_/g, ' ')}</span>
            </span>
            <ChevronDown className="h-4 w-4 text-gray-400" />
          </button>

          {profileMenuOpen && (
            <div role="menu" className="absolute right-0 top-full mt-2 w-56 overflow-hidden rounded-xl border border-gray-200 bg-white py-1 shadow-lg">
              <Link
                to="/profile"
                role="menuitem"
                onClick={() => setProfileMenuOpen(false)}
                className="flex items-center gap-3 px-4 py-3 text-sm text-gray-700 hover:bg-gray-50"
              >
                <UserRound className="h-4 w-4 text-gray-400" /> Profile &amp; password
              </Link>
              <button
                type="button"
                role="menuitem"
                onClick={logout}
                className="flex w-full items-center gap-3 border-t border-gray-100 px-4 py-3 text-left text-sm text-red-600 hover:bg-red-50"
              >
                <LogOut className="h-4 w-4" /> Sign out
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
