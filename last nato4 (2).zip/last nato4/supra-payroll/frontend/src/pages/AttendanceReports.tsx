import { useState, useEffect } from 'react';
import { toast } from 'react-hot-toast';
import api from '../services/api';
import { Printer, Calendar } from 'lucide-react';

export default function AttendanceReports() {
  const [records, setRecords] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({ employee_id: '', start_date: '', end_date: '' });

  useEffect(() => {
    loadRecords();
  }, [filters]);

  const loadRecords = async () => {
    setLoading(true);
    try {
      const res = await api.get('/attendance/', { params: filters });
      setRecords(res.data.records);
    } catch (err) {
      toast.error('Failed to load attendance records');
    } finally {
      setLoading(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Attendance Reports</h1>
          <p className="text-gray-500">Generate and print attendance reports</p>
        </div>
        <div className="flex items-center gap-3">
          <button onClick={handlePrint} className="supra-btn-primary flex items-center gap-2">
            <Printer className="w-4 h-4" />
            Print Report
          </button>
        </div>
      </div>

      <div className="supra-card p-6">
        <div className="flex flex-wrap items-center gap-4 mb-6">
          <input
            type="date"
            value={filters.start_date}
            onChange={(e) => setFilters({ ...filters, start_date: e.target.value })}
            className="supra-input"
          />
          <input
            type="date"
            value={filters.end_date}
            onChange={(e) => setFilters({ ...filters, end_date: e.target.value })}
            className="supra-input"
          />
          <button onClick={loadRecords} className="supra-btn-secondary px-4">
            <Calendar className="w-4 h-4 mr-2" />
            Filter
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="supra-table">
            <thead>
              <tr>
                <th>Employee ID</th>
                <th>Employee Name</th>
                <th>Date</th>
                <th>Time In</th>
                <th>Time Out</th>
                <th>Total Hours</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={7} className="text-center py-8 text-gray-500">Loading...</td></tr>
              ) : records.length === 0 ? (
                <tr><td colSpan={7} className="text-center py-8 text-gray-500">No attendance records found.</td></tr>
              ) : (
                records.map((r) => (
                  <tr key={r.id} className="hover:bg-gray-50/50 transition-colors">
                    <td className="font-medium text-gray-900">{r.employee_id}</td>
                    <td className="text-gray-700">{r.first_name} {r.last_name}</td>
                    <td className="text-gray-700 text-sm">{r.attendance_date}</td>
                    <td className="text-gray-700 text-sm">{r.time_in || '-'}</td>
                    <td className="text-gray-700 text-sm">{r.time_out || '-'}</td>
                    <td className="text-gray-700 text-sm">{r.total_hours || 0}</td>
                    <td>
                      <span className={`supra-badge ${r.status === 'Present' ? 'badge-present' : 'badge-absent'}`}>
                        {r.status}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
