# SUPRA Employee Management and Payroll System

A complete, functional, responsive full-stack web application for managing employee information, attendance records, payroll processing, payslip generation, and employee 201 files.

**Company:** SUPRA  
**System:** SUPRA Employee Management and Payroll System  
**Design:** Modern, professional, minimalist corporate HR system with bold red-and-black automotive identity

---

## 📁 Project Structure

```
supra-payroll/
├── backend/                 # Node.js/Express API server
│   ├── .env                 # Environment variables
│   ├── .env.example         # Environment configuration template
│   ├── package.json         # Backend dependencies
│   ├── database/            # SQLite database file
│   ├── uploads/             # Employee document storage
│   └── src/
│       ├── app.js           # Express app configuration
│       ├── server.js        # Server entry point
│       ├── controllers/     # Route controllers
│       ├── database/        # Database setup, schema, migrations, seeds
│       ├── middleware/      # Custom middleware
│       └── routes/          # API route definitions
└── frontend/                # React + TypeScript + Tailwind CSS
    ├── index.html
    ├── package.json
    ├── tailwind.config.js   # SUPRA brand colors
    ├── postcss.config.js
    ├── vite.config.ts       # Vite dev server with API proxy
    ├── tsconfig.json
    └── src/
        ├── main.tsx
        ├── index.css
        ├── App.tsx
        ├── services/api.ts
        ├── contexts/AuthContext.tsx
        ├── types/index.ts
        ├── components/
        └── pages/
```

---

## 🚀 Quick Start

### Prerequisites

- **Node.js** v18 or higher ([Download](https://nodejs.org/))
- **npm** (comes with Node.js)

### Installation

1. **Install backend dependencies:**
   ```bash
   cd supra-payroll/backend
   npm install
   ```

2. **Install frontend dependencies:**
   ```bash
   cd ../frontend
   npm install
   ```

3. **Initialize the database:**
   ```bash
   cd ../backend
   npm run setup
   ```

4. **Start the backend server:**
   ```bash
   npm run dev
   ```
   Server runs on `http://localhost:5000`

5. **Start the frontend development server:**
   ```bash
   cd ../frontend
   npm run dev
   ```
   Frontend runs on `http://localhost:3000`

6. **Open your browser** at `http://localhost:3000`

---

## 🔐 Demo Accounts

Five initial user accounts are created during development setup. Users can change their password at any time from the profile menu after signing in.

In development, setup also adds fictional employee records for Saraza, Sampayan, Santos, and Sison, confirmed demo payslips, and private sample employee files so the dashboard modules have content. On the hosted demo, set `SEED_DEMO_DATA=true` to seed the same fictional sample data while keeping `NODE_ENV=production`.

| Name | Username | Password | Role |
|------|----------|----------|------|
| Tan | tan | Tan123 | Administrator |
| Saraza | saraza | Saraza123 | HR/Payroll Staff |
| Santos | santos | Santos123 | HR/Payroll Staff |
| Sampayan | sampayan | Sampayan123 | HR/Payroll Staff |
| Sison | sison | Sison123 | HR/Payroll Staff |

---

## 📋 Features

### Authentication
- Secure login with username/email and password
- Show/hide password toggle
- Registration with validation (prevents duplicates)
- Password hashing with bcrypt (12 salt rounds)
- JWT-based sessions
- Mandatory password change on first login
- Role-based access control (Administrator / HR/Payroll Staff)

### Dashboard
- Summary cards: Total Employees, Present Today, Absent Today, Pending Payroll
- Welcome message with logged-in user's name
- Quick access to all 5 main modules
- Recent activity and payroll summary

### Manage Employees
- Add new employee (14 fields including auto-generated Employee ID)
- View, edit, archive employee records
- Search by name or Employee ID
- Filter by department and employment status
- Paginated employee table

### Record Attendance
- Time-in / Time-out recording
- Automatic date/time capture from server
- Total hours calculation
- Attendance records with filters
- Print-friendly attendance reports

### Process Payroll
- Select employee and payroll period
- Automatic calculation of earnings and deductions
- Philippine payroll rules (SSS, PhilHealth, Pag-IBIG, tax brackets)
- Overtime calculation (1.25x multiplier beyond 8 hours)
- Draft → Confirm → Paid workflow
- Duplicate payroll prevention

### Generate Payslip
- Select employee and period from saved payroll records
- Professional payslip layout with SUPRA branding
- Earnings and deductions breakdown
- Browser printing and PDF export

### Employee 201 Files
- Upload employee documents (PDF, DOC, images, spreadsheets)
- Document categories (Contract, Resume, ID, Educational, etc.)
- Download authorized documents
- File type and size validation

### User Management (Administrator only)
- View, add, update, deactivate users
- Role assignment
- Password reset

### Activity Logs (Administrator only)
- Complete audit trail of system actions
- User, action, entity, description, timestamp

### Security
- Server-side role-based access control
- Protected API endpoints
- Input validation and sanitization
- Private file storage
- No sensitive data exposed in URLs
- Activity logging for all sensitive operations

---

## 🛠️ Available Scripts

### Backend
| Script | Description |
|--------|-------------|
| `npm start` | Start production server |
| `npm run dev` | Start development server with nodemon |
| `npm run migrate` | Run database migrations |
| `npm run seed` | Seed database with demo accounts |
| `npm run setup` | Full database setup (migrate + seed) |

### Frontend
| Script | Description |
|--------|-------------|
| `npm run dev` | Start development server (Vite) |
| `npm run build` | Build for production |
| `npm run preview` | Preview production build |

---

## 🎨 Design System

**Colors:**
- **Black:** `#0a0a0a` - Navigation, headers, accents
- **Red:** `#dc2626` - Primary buttons, highlights, alerts
- **White:** `#ffffff` - Content panels, text on dark backgrounds
- **Charcoal:** `#1a1a1a` - Supporting backgrounds
- **Light Gray:** `#f3f4f6` - Backgrounds, borders

**Typography:** Inter (sans-serif), system-ui fallback

**Logo:** Original SUPRA logo with stylized sports-car silhouette motif

---

## 🗄️ Database

**Type:** SQLite (single file, zero-configuration)

**Tables:**
1. `users` - System accounts with roles
2. `employees` - Employee records
3. `attendance` - Time-in/out records
4. `payroll` - Payroll calculations
5. `payroll_settings` - Configurable payroll rules
6. `payslips` - Generated payslip records
7. `employee_201_files` - Employee documents
8. `activity_logs` - Audit trail
9. `departments` - Department list

**Database file:** `backend/database/supra.db`

---

## 📄 License

This project is developed for educational/demo purposes as a school project.
