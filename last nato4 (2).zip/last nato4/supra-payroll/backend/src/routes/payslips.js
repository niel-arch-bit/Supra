const express = require('express');
const router = express.Router();
const payslipController = require('../controllers/payslipController');
const { authenticateToken, requireActiveUser } = require('../middleware/auth');

router.get('/', authenticateToken, requireActiveUser, payslipController.getAll);
router.get('/:id', authenticateToken, requireActiveUser, payslipController.getById);
router.post('/generate', authenticateToken, requireActiveUser, payslipController.generate);

module.exports = router;