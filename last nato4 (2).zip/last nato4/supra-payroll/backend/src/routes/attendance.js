const express = require('express');
const router = express.Router();
const attendanceController = require('../controllers/attendanceController');
const { authenticateToken, requireActiveUser, authorizeRoles } = require('../middleware/auth');

router.post('/record', authenticateToken, requireActiveUser, authorizeRoles('administrator', 'hr_payroll_staff'), attendanceController.recordAttendance);
router.get('/', authenticateToken, requireActiveUser, attendanceController.getAll);
router.get('/summary', authenticateToken, requireActiveUser, attendanceController.getSummary);
router.put('/:id', authenticateToken, requireActiveUser, authorizeRoles('administrator', 'hr_payroll_staff'), attendanceController.update);

module.exports = router;