const jwt = require('jsonwebtoken');
const Database = require('better-sqlite3');
const { DB_PATH } = require('../config/storage');
const db = new Database(DB_PATH);
db.pragma('foreign_keys = ON');

const JWT_SECRET = process.env.JWT_SECRET || 'your_supra_jwt_secret_change_in_production';

// Authenticate token middleware
function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Access denied. No token provided.' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid or expired token.' });
    }
    req.user = user;
    next();
  });
}

// Role-based access control
function authorizeRoles(...allowedRoles) {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Authentication required.' });
    }
    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).json({ error: 'Insufficient permissions.' });
    }
    next();
  };
}

// Get user from database by ID
function getUserById(userId) {
  return db.prepare('SELECT id, username, email, full_name, role, is_active, must_change_password FROM users WHERE id = ?').get(userId);
}

// Verify user is active
function requireActiveUser(req, res, next) {
  if (!req.user) {
    return res.status(401).json({ error: 'Authentication required.' });
  }
  const user = getUserById(req.user.id);
  if (!user || !user.is_active) {
    return res.status(403).json({ error: 'Account is deactivated. Contact administrator.' });
  }
  req.user = { ...req.user, ...user };
  next();
}

module.exports = {
  authenticateToken,
  authorizeRoles,
  requireActiveUser,
  JWT_SECRET,
  db
};
