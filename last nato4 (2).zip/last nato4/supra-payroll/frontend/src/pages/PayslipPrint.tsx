import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { toast } from 'react-hot-toast';
import api from '../services/api';
import { SupraLogo } from '../components/SupraLogo';
import { ArrowLeft, Printer, Download } from 'lucide-react';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

export default function PayslipPrint() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [payslip, setPayslip] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadPayslip();
  }, [id]);

  const loadPayslip = async () => {
    try {
      const res = await api.get(`/payslips/${id}`);
      setPayslip(res.data.payslip);
    } catch (err) {
      toast.error('Failed to load payslip');
    } finally {
      setLoading(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handlePDF = async () => {
    const element = document.getElementById('payslip-print');
    if (!element) return;
    const canvas = await html2canvas(element);
    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF('p', 'mm', 'a4');
    const imgProps = pdf.getImageProperties(imgData);
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
    pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
    pdf.save(`payslip_${payslip?.employee_id_str || 'employee'}_${payslip?.period_start || 'period'}.pdf`);
  };

  if (loading || !payslip) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-supra-red-600 mx-auto mb-4"></div>
          <p className="text-gray-500">Loading payslip...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <button onClick={() => navigate('/payslip/view')} className="flex items-center gap-2 text-gray-600 hover:text-supra-red-600 mb-4">
            <ArrowLeft className="w-4 h-4" />
            Back to Payslips
          </button>
          <h1 className="text-2xl font-bold text-gray-900">Payslip</h1>
          <p className="text-gray-500">SUPRA Employee Management and Payroll System</p>
        </div>
        <div className="flex items-center gap-3">
          <button onClick={handlePDF} className="supra-btn-secondary flex items-center gap-2">
            <Download className="w-4 h-4" />
            PDF
          </button>
          <button onClick={handlePrint} className="supra-btn-primary flex items-center gap-2 hidden sm:block">
            <Printer className="w-4 h-4" />
            Print
          </button>
        </div>
      </div>

      <div id="payslip-print" className="print:absolute print:top-0 print:left-0 print:w-full print:h-full print:bg-white print:scale-90 max-w-2xl mx-auto bg-white p-8 rounded-2xl border border-gray-200 shadow-xl">
        <div className="flex items-center justify-between mb-8">
          <div>
            <SupraLogo size="md" className="text-supra-black-900 mb-2" />
            <h2 className="text-sm font-bold text-gray-700 uppercase tracking-widest">Employee Payslip</h2>
          </div>
          <div className="text-right">
            <p className="text-xs font-semibold text-gray-400 uppercase">Date Generated</p>
            <p className="text-sm text-gray-500">{new Date().toLocaleDateString()}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div>
            <p className="text-xs font-semibold text-gray-400 uppercase">Employee</p>
            <p className="text-lg font-bold text-gray-900">{payslip.first_name} {payslip.last_name}</p>
            <p className="text-sm text-gray-500">ID: {payslip.employee_id_str}</p>
          </div>
          <div>
            <p className="text-xs font-semibold text-gray-400 uppercase">Position</p>
            <p className="text-lg font-bold text-gray-900">{payslip.job_position || 'N/A'}</p>
            <p className="text-sm text-gray-500">{payslip.department_name || 'N/A'}</p>
          </div>
        </div>

        <div className="overflow-hidden border border-gray-200 rounded-xl mb-8">
          <table className="w-full text-left">
            <thead className="bg-supra-black">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-bold text-white uppercase">Description</th>
                <th className="px-6 py-3 text-right text-xs font-bold text-white uppercase">Amount</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              <tr>
                <td className="px-6 py-4 text-gray-700">Basic Pay</td>
                <td className="px-6 py-4 text-right text-gray-700">₱{payslip.basic_pay}</td>
              </tr>
              <tr>
                <td className="px-6 py-4 text-gray-700">Overtime Pay</td>
                <td className="px-6 py-4 text-right text-gray-700">₱{payslip.overtime_pay}</td>
              </tr>
              <tr>
                <td className="px-6 py-4 text-gray-700">Allowances</td>
                <td className="px-6 py-4 text-right text-gray-700">₱{payslip.allowances}</td>
              </tr>
              <tr>
                <td className="px-6 py-4 text-gray-700">Bonuses</td>
                <td className="px-6 py-4 text-right text-gray-700">₱{payslip.bonuses}</td>
              </tr>
              <tr className="bg-gray-50">
                <td className="px-6 py-4 font-semibold text-gray-900">Total Earnings</td>
                <td className="px-6 py-4 text-right font-semibold text-gray-900">₱{payslip.total_earnings}</td>
              </tr>
              <tr>
                <td className="px-6 py-4 text-gray-700">Absence Deduction</td>
                <td className="px-6 py-4 text-right text-gray-700">₱{payslip.absence_deduction}</td>
              </tr>
              <tr>
                <td className="px-6 py-4 text-gray-700">Government Contributions</td>
                <td className="px-6 py-4 text-right text-gray-700">₱{payslip.government_contributions}</td>
              </tr>
              <tr>
                <td className="px-6 py-4 text-gray-700">Tax Withholding</td>
                <td className="px-6 py-4 text-right text-gray-700">₱{payslip.tax_withholding}</td>
              </tr>
              <tr className="bg-gray-50">
                <td className="px-6 py-4 font-semibold text-gray-900">Total Deductions</td>
                <td className="px-6 py-4 text-right font-semibold text-gray-900">₱{payslip.total_deductions}</td>
              </tr>
              <tr className="bg-supra-red-50 border-t-2 border-supra-red-600">
                <td className="px-6 py-4 font-bold text-supra-red-900">Net Pay</td>
                <td className="px-6 py-4 text-right font-bold text-supra-red-900">₱{payslip.net_pay}</td>
              </tr>
            </tbody>
          </table>
        </div>

        <div className="grid grid-cols-2 gap-6 pt-8 border-t border-gray-200">
          <div>
            <p className="text-xs font-semibold text-gray-400 uppercase">Period</p>
            <p className="text-sm text-gray-700">{payslip.period_start} to {payslip.period_end}</p>
          </div>
          <div className="text-right">
            <p className="text-xs font-semibold text-gray-400 uppercase">Prepared By</p>
            <p className="text-sm text-gray-700">{payslip.processed_by_name || 'HR/Payroll Staff'}</p>
          </div>
        </div>

        <div className="mt-8 text-center">
          <p className="text-xs text-gray-400 uppercase tracking-widest">SUPRA Employee Management and Payroll System</p>
          <p className="text-xs text-gray-500">This is a computer-generated payslip and does not require a signature.</p>
        </div>
      </div>

      <button onClick={handlePrint} className="supra-btn-primary w-full sm:w-auto px-8 sm:hidden">
        <Printer className="w-4 h-4 mr-2" />
        Print Payslip
      </button>
    </div>
  );
}
