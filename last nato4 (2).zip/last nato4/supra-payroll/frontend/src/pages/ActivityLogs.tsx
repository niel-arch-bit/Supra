import { useState, useEffect } from 'react';
import { toast } from 'react-hot-toast';
import api from '../services/api';

export default function ActivityLogs() {
  const [logs, setLogs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadLogs();
  }, []);

  const loadLogs = async () => {
    setLoading(true);
    try {
      const res = await api.get('/activity-logs/');
      setLogs(res.data.logs);
    } catch (err) {
      toast.error('Failed to load activity logs');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Activity Logs</h1>
          <p className="text-gray-500">System activity and audit trail</p>
        </div>
      </div>

      <div className="supra-card p-6">
        <div className="overflow-x-auto">
          <table className="supra-table">
            <thead>
              <tr>
                <th>User</th>
                <th>Action</th>
                <th>Entity</th>
                <th>Description</th>
                <th>Date & Time</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={5} className="text-center py-8 text-gray-500">Loading...</td></tr>
              ) : logs.length === 0 ? (
                <tr><td colSpan={5} className="text-center py-8 text-gray-500">No activity logs found.</td></tr>
              ) : (
                logs.map((l) => (
                  <tr key={l.id} className="hover:bg-gray-50/50 transition-colors">
                    <td className="font-medium text-gray-900">{l.username || 'System'}</td>
                    <td className="text-gray-700 text-sm">{l.action}</td>
                    <td className="text-gray-700 text-sm">{l.entity_type || '-'}</td>
                    <td className="text-gray-700 text-sm">{l.description || '-'}</td>
                    <td className="text-gray-700 text-sm">{l.created_at}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
