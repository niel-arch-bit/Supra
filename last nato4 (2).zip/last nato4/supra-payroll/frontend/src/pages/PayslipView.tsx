import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-hot-toast';
import api from '../services/api';
import { ArrowLeft, FileText, Search } from 'lucide-react';

export default function PayslipView() {
  const navigate = useNavigate();
  const [records, setRecords] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [employeeFilter, setEmployeeFilter] = useState('');

  useEffect(() => {
    loadRecords();
  }, [employeeFilter]);

  const loadRecords = async () => {
    setLoading(true);
    try {
      const res = await api.get('/payslips/', { params: { employee_id: employeeFilter || undefined } });
      setRecords(res.data.records);
    } catch (err) {
      toast.error('Failed to load payslips');
    } finally {
      setLoading(false);
    }
  };

  const viewPayslip = (id: number) => {
    navigate(`/payslip/print/${id}`);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <button onClick={() => navigate('/dashboard')} className="flex items-center gap-2 text-gray-600 hover:text-supra-red-600 mb-4">
            <ArrowLeft className="w-4 h-4" />
            Back to Dashboard
          </button>
          <h1 className="text-2xl font-bold text-gray-900">Generate Payslip</h1>
          <p className="text-gray-500">View and print employee payslips</p>
        </div>
      </div>

      <div className="supra-card p-6">
        <div className="flex items-center gap-4 mb-6">
          <input
            type="text"
            value={employeeFilter}
            onChange={(e) => setEmployeeFilter(e.target.value)}
            placeholder="Search by employee name or ID"
            className="supra-input flex-1 max-w-md"
          />
          <button onClick={loadRecords} className="supra-btn-secondary px-4">
            <Search className="w-4 h-4 mr-2" />
            Search
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="supra-table">
            <thead>
              <tr>
                <th>Employee ID</th>
                <th>Employee Name</th>
                <th>Period</th>
                <th>Net Pay</th>
                <th className="text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={5} className="text-center py-8 text-gray-500">Loading...</td></tr>
              ) : records.length === 0 ? (
                <tr><td colSpan={5} className="text-center py-8 text-gray-500">No payslips found.</td></tr>
              ) : (
                records.map((r) => (
                  <tr key={r.id} className="hover:bg-gray-50/50 transition-colors">
                    <td className="font-medium text-gray-900">{r.employee_id_str}</td>
                    <td className="text-gray-700">{r.first_name} {r.last_name}</td>
                    <td className="text-gray-700 text-sm">{r.period_start} to {r.period_end}</td>
                    <td className="text-gray-700 text-sm font-medium">₱{r.net_pay}</td>
                    <td className="text-right">
                      <button
                        onClick={() => viewPayslip(r.id)}
                        className="supra-btn-primary px-4 py-2 text-sm"
                      >
                        <FileText className="w-4 h-4 mr-1" />
                        View
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
