import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-hot-toast';
import api from '../services/api';
import { ArrowLeft, Upload } from 'lucide-react';
import type { Employee } from '../types';

export default function Employee201Upload() {
  const navigate = useNavigate();
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [formData, setFormData] = useState({ employee_id: '', document_name: '', document_category: '' });
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    api.get('/employees/', { params: { archived: 'false', limit: 100 } })
      .then((res) => setEmployees(res.data.employees))
      .catch(() => toast.error('Failed to load employees'));
  }, []);

  const categories = [
    'Employment Contract',
    'Resume or Application Form',
    'Identification Documents',
    'Government Registration Documents',
    'Educational Records',
    'Certificates and Training',
    'Performance Evaluations',
    'Other Employment Documents'
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) {
      toast.error('Please select a file to upload.');
      return;
    }
    setUploading(true);
    const uploadData = new FormData();
    uploadData.append('document', file);
    uploadData.append('employee_id', formData.employee_id);
    uploadData.append('document_name', formData.document_name);
    uploadData.append('document_category', formData.document_category);
    try {
      await api.post('/employee201/upload', uploadData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      toast.success('Document uploaded successfully!');
      navigate('/employee201');
    } catch (err: any) {
      toast.error(err.response?.data?.error || 'Failed to upload document.');
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <button onClick={() => navigate('/employee201')} className="flex items-center gap-2 text-gray-600 hover:text-supra-red-600 mb-4">
            <ArrowLeft className="w-4 h-4" />
            Back to Employee Files
          </button>
          <h1 className="text-2xl font-bold text-gray-900">Upload Document</h1>
          <p className="text-gray-500">Add document to employee 201 file</p>
        </div>
      </div>

      <div className="supra-card p-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Select Employee</label>
              <select
                value={formData.employee_id}
                onChange={(e) => setFormData({ ...formData, employee_id: e.target.value })}
                className="supra-input"
                required
              >
                <option value="">-- Select Employee --</option>
                {employees.map((e) => (
                  <option key={e.id} value={e.id}>{e.employee_id} - {e.first_name} {e.last_name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Document Name</label>
              <input
                type="text"
                value={formData.document_name}
                onChange={(e) => setFormData({ ...formData, document_name: e.target.value })}
                className="supra-input"
                placeholder="Document name"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Document Category</label>
              <select
                value={formData.document_category}
                onChange={(e) => setFormData({ ...formData, document_category: e.target.value })}
                className="supra-input"
                required
              >
                <option value="">-- Select Category --</option>
                {categories.map((cat) => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>
            <div className="col-span-1">
              <label className="block text-sm font-medium text-gray-700 mb-2">Select File</label>
              <label htmlFor="employee201-file" className="border-2 border-dashed border-gray-200 rounded-xl p-6 flex items-center justify-center gap-3 text-gray-500 hover:border-supra-red-500 hover:text-supra-red-600 transition-colors cursor-pointer bg-gray-50/50">
                <Upload className="w-6 h-6" />
                <span>Choose a file to upload</span>
              </label>
              <input
                id="employee201-file"
                type="file"
                onChange={(e) => {
                  if (e.target.files?.[0]) setFile(e.target.files[0]);
                }}
                className="sr-only"
                accept=".pdf,.doc,.docx,.jpg,.jpeg,.png,.xlsx,.xls,.csv,.txt"
                required
              />
              {file && (
                <p className="text-sm text-gray-600 mt-2">Selected: {file.name} ({Math.round(file.size / 1024)} KB)</p>
              )}
            </div>
          </div>

          <button
            type="submit"
            disabled={uploading}
            className="supra-btn-primary w-full py-4 disabled:opacity-60 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {uploading ? (
              <span>Uploading...</span>
            ) : (
              <>
                <Upload className="w-4 h-4" />
                Upload Document
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
}
