export function SupraLogo({ className = '', size = 'lg' }: { className?: string; size?: 'sm' | 'md' | 'lg' }) {
  const sizes = { sm: 'text-xl', md: 'text-2xl', lg: 'text-3xl' };
  return (
    <div className={`flex items-center gap-3 ${className}`}>
      <div className="w-10 h-10 bg-supra-red-600 rounded-2xl flex items-center justify-center shadow-supr-red relative overflow-hidden">
        <div className="absolute inset-0 bg-black/20" />
        <svg className="w-6 h-6 text-white z-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" />
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 20V5l5-3 5 3v15" />
        </svg>
      </div>
      <span className={`supra-logo font-bold tracking-tight ${sizes[size]}`}>SUPRA</span>
    </div>
  );
}
