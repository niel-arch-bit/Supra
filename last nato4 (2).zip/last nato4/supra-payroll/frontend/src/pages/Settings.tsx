import { useState, useEffect } from 'react';
import { toast } from 'react-hot-toast';
import api from '../services/api';
import { Settings as SettingsIcon, ArrowLeft } from 'lucide-react';

export default function Settings() {
  const [settings, setSettings] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [editMode, setEditMode] = useState<string | null>(null);
  const [editValue, setEditValue] = useState('');

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    setLoading(true);
    try {
      const res = await api.get('/payroll/settings');
      setSettings(res.data.settings);
    } catch (err) {
      toast.error('Failed to load settings');
    } finally {
      setLoading(false);
    }
  };

  const updateSetting = async (key: string) => {
    try {
      await api.post('/payroll/settings', { setting_key: key, setting_value: editValue });
      toast.success('Setting updated successfully!');
      setEditMode(null);
      loadSettings();
    } catch (err: any) {
      toast.error(err.response?.data?.error || 'Failed to update setting.');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <button onClick={() => {}} className="flex items-center gap-2 text-gray-600 hover:text-supra-red-600 mb-4">
            <ArrowLeft className="w-4 h-4" />
            Back
          </button>
          <h1 className="text-2xl font-bold text-gray-900">Settings</h1>
          <p className="text-gray-500">System configuration and payroll settings</p>
        </div>
      </div>

      <div className="supra-card p-6">
        <div className="overflow-x-auto">
          <table className="supra-table">
            <thead>
              <tr>
                <th>Setting</th>
                <th>Description</th>
                <th>Current Value</th>
                <th className="text-right">Action</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={4} className="text-center py-8 text-gray-500">Loading...</td></tr>
              ) : settings.length === 0 ? (
                <tr><td colSpan={4} className="text-center py-8 text-gray-500">No settings found.</td></tr>
              ) : (
                settings.map((s) => (
                  <tr key={s.setting_key} className="hover:bg-gray-50/50 transition-colors">
                    <td className="font-medium text-gray-900">{s.setting_key.replace(/_/g, ' ')}</td>
                    <td className="text-gray-700 text-sm">{s.description || '-'}</td>
                    <td>
                      {editMode === s.setting_key ? (
                        <input
                          type="text"
                          value={editValue}
                          onChange={(e) => setEditValue(e.target.value)}
                          className="supra-input text-sm"
                          autoFocus
                        />
                      ) : (
                        <span className="text-gray-700 text-sm">{s.setting_value}</span>
                      )}
                    </td>
                    <td className="text-right">
                      {editMode === s.setting_key ? (
                        <>
                          <button
                            onClick={() => updateSetting(s.setting_key)}
                            className="text-supra-red-600 hover:text-supra-red-800 mr-2" title="Save"
                          >
                            ✓
                          </button>
                          <button
                            onClick={() => setEditMode(null)}
                            className="text-gray-500 hover:text-gray-700" title="Cancel"
                          >
                            ✕
                          </button>
                        </>
                      ) : (
                        <button
                          onClick={() => { setEditMode(s.setting_key); setEditValue(s.setting_value); }}
                          className="text-supra-red-600 hover:text-supra-red-800" title="Edit"
                        >
                          <SettingsIcon className="w-4 h-4" />
                        </button>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
