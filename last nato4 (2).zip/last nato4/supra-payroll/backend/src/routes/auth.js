const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const { authenticateToken, requireActiveUser } = require('../middleware/auth');

router.post('/login', authController.login);
router.post('/register', authController.register);
router.get('/me', authenticateToken, requireActiveUser, authController.me);
router.post('/change-password', authenticateToken, requireActiveUser, authController.changePassword);
router.post('/logout', authenticateToken, requireActiveUser, authController.logout);

module.exports = router;