const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');
const { logActivity } = require('../middleware/activityLogger');
const { upload, UPLOAD_PATH } = require('../middleware/upload');

const { DB_PATH } = require('../config/storage');
const db = new Database(DB_PATH);
db.pragma('foreign_keys = ON');

exports.getAll = (req, res) => {
  try {
    const { employee_id } = req.query;
    let query = `
      SELECT f.*, e.employee_id as employee_id_str, e.first_name, e.last_name,
        u.full_name as uploaded_by_name
      FROM employee_201_files f
      JOIN employees e ON f.employee_id = e.id
      JOIN users u ON f.uploaded_by = u.id
      WHERE 1=1
    `;
    const params = [];
    if (employee_id) {
      query += ` AND f.employee_id = ?`;
      params.push(employee_id);
    }
    query += ` ORDER BY f.upload_date DESC`;

    const files = db.prepare(query).all(params);
    res.json({ files });
  } catch (err) {
    console.error('Get employee files error:', err);
    res.status(500).json({ error: 'Internal server error.' });
  }
};

exports.uploadDocument = (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded.' });
    }

    const { employee_id, document_name, document_category } = req.body;
    if (!employee_id || !document_name || !document_category) {
      fs.unlinkSync(req.file.path);
      return res.status(400).json({ error: 'Employee ID, document name, and category are required.' });
    }

    const stmt = db.prepare(`
      INSERT INTO employee_201_files (employee_id, document_name, document_category, file_name, file_path, file_type, file_size, uploaded_by)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);
    const result = stmt.run(
      employee_id, document_name, document_category,
      req.file.filename, req.file.path, req.file.mimetype, req.file.size, req.user.id
    );

    logActivity(req.user.id, req.user.username, 'DOCUMENT_UPLOADED', 'employee_file', result.lastInsertRowid,
      `Uploaded document: ${document_name}`, req);

    res.status(201).json({ message: 'Document uploaded successfully.', id: result.lastInsertRowid });
  } catch (err) {
    console.error('Upload document error:', err);
    res.status(500).json({ error: 'Internal server error.' });
  }
};

exports.downloadDocument = (req, res) => {
  try {
    const file = db.prepare(`
      SELECT f.*, e.employee_id
      FROM employee_201_files f
      JOIN employees e ON f.employee_id = e.id
      WHERE f.id = ?
    `).get(req.params.id);

    if (!file) {
      return res.status(404).json({ error: 'Document not found.' });
    }

    if (!fs.existsSync(file.file_path)) {
      return res.status(404).json({ error: 'File not found on server.' });
    }

    logActivity(req.user.id, req.user.username, 'DOCUMENT_DOWNLOADED', 'employee_file', file.id,
      `Downloaded document: ${file.document_name}`, req);

    res.download(file.file_path, file.file_name);
  } catch (err) {
    console.error('Download document error:', err);
    res.status(500).json({ error: 'Internal server error.' });
  }
};

exports.deleteDocument = (req, res) => {
  try {
    const file = db.prepare('SELECT * FROM employee_201_files WHERE id = ?').get(req.params.id);
    if (!file) {
      return res.status(404).json({ error: 'Document not found.' });
    }

    if (fs.existsSync(file.file_path)) {
      fs.unlinkSync(file.file_path);
    }

    db.prepare('DELETE FROM employee_201_files WHERE id = ?').run(req.params.id);

    logActivity(req.user.id, req.user.username, 'DOCUMENT_DELETED', 'employee_file', req.params.id,
      `Deleted document: ${file.document_name}`, req);

    res.json({ message: 'Document deleted successfully.' });
  } catch (err) {
    console.error('Delete document error:', err);
    res.status(500).json({ error: 'Internal server error.' });
  }
};
